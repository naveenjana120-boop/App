# Limitations and Educational Boundary

**EDUCATIONAL PURPOSE ONLY.** Use only files you own or are authorized to inspect or modify.

## What works in the active source set

- **Generic NPAK v1 archive:** build a synthetic archive, inspect its index, extract entries, replace existing files, add new files, and rebuild its footer.
- **Streaming I/O:** archive payloads are copied in 64 KiB chunks. Unencrypted payloads are not loaded entirely into memory during build, repack, or extraction.
- **Integrity:** SHA-256 is stored for each plaintext payload and for the index. Footer and entry hashes are verified when reading/extracting.
- **Generic cryptography:** AES-GCM helpers include streaming encrypt/decrypt paths and authentication-tag verification. Encrypted file entries require the same key to extract.
- **Android file access:** the UI uses Android's Storage Access Framework and app-private temporary files.
- **Lua source:** standard UTF-8 Lua source can be opened, edited, viewed, and saved.
- **Optional Lua bytecode tools:** compiler and decompiler calls are attempted only when compatible local tools are available; otherwise the UI reports the missing backend.

## What does not work

- No BGMI/Tencent proprietary PAK parsing, writing, footer encryption, version-specific key handling, asset injection, or compatibility claim.
- No game-specific Lua bytecode conversion is exposed by the active app.
- No live process injection, anti-cheat bypass, online-service interference, or runtime game modification.
- No Lua compiler or `unluac.jar` is bundled. The app does not fabricate successful output when tools are missing.
- AES-GCM encrypted entries use an externally supplied key. Keys are not embedded in the archive; losing the key makes the entry unrecoverable.
- Index parsing is memory-bounded to 64 MiB and 250,000 entries. Paths are limited to 16 KiB UTF-8. Single-file byte-array convenience helpers remain unsuitable for very large files; use the streaming methods.
- Full Android build/device testing was not possible in the offline environment used for this review.

## Why the boundary exists

This release is a generic learning project, not a game-specific modification utility. Proprietary archive formats, protected asset workflows, and anti-cheat evasion raise legal, licensing, and fair-play concerns. Keeping the active implementation on a synthetic format makes serialization, integrity, streaming, and encryption testable without reproducing protected game-specific behavior.

## Preserved historical source

Files from earlier batches that are version-specific or inconsistent with the generic format are retained in `legacy-source/` for reference only. They are **not compiled**, not wired into the UI, and not part of the generic APK. This avoids silently discarding the historical material while keeping the active build within the documented educational scope.
