# NPAK v1 — Synthetic Archive Format

**EDUCATIONAL PURPOSE ONLY.** NPAK is a deliberately synthetic format and is not compatible with any proprietary game PAK format.

All integer fields are little-endian. Payload data is contiguous after the 8-byte header. Index bytes follow payload data, and a fixed 72-byte footer is the final structure.

## Header (8 bytes)

| Offset | Size | Meaning |
|---:|---:|---|
| 0 | 4 | ASCII `NPAK` |
| 4 | 4 | Version `1` as uint32 little-endian |

## Index

The index begins at the footer's `indexOffset` and is limited to 64 MiB.

| Field | Encoding |
|---|---|
| Magic | 4 bytes `NIDX` |
| Index version | uint32 = 1 |
| Entry count | uint32 |
| Each path | uint32 UTF-8 byte length, then path bytes (no NUL terminator) |
| Offset | uint64 payload offset from start of file |
| Stored size | uint64 number of bytes stored in the archive |
| Original size | uint64 plaintext size |
| Flags | uint32; bit 0 means AES-GCM encrypted |
| SHA-256 | 32 bytes of the plaintext payload |

Paths must be relative, use `/` separators, and may not contain empty, `.` or `..` components. Duplicate paths are rejected case-insensitively.

## Footer (72 bytes)

| Field | Size |
|---|---:|
| Magic `NPAKEND1` | 8 |
| Footer version = 1 | 4 |
| Flags = 0 | 4 |
| Index offset | 8 |
| Index length | 8 |
| Entry count | 4 |
| Reserved = 0 | 4 |
| SHA-256 of stored index bytes | 32 |

The parser requires the index to end exactly where the footer begins. It validates the index hash, entry count, ranges, and payload overlap.

## AES-GCM entry encoding

When an entry is marked encrypted, its stored bytes are a 12-byte random nonce followed by AES-GCM ciphertext and a 16-byte authentication tag. The key is supplied out of band. The index hash is the SHA-256 of the plaintext. Extraction writes to a temporary file and only publishes it after GCM authentication and hash validation succeed.
