# Final Project Documentation

**EDUCATIONAL PURPOSE ONLY.**

## Active architecture

- `ui/`: Android activities, navigation, and document-picker workflows.
- `core/SafFileBridge.java`: bounded streaming copies between SAF documents and app-private working directories.
- `core/LuaCompiler.java` and `core/LuaDecompiler.java`: optional standard Lua tool adapters.
- `npak/`: synthetic archive writer, index/footer codec, AES-GCM helper, builder, repacker, injector, operations facade, and self-test.
- `legacy-source/`: historical source retained for reference but excluded from the app's compile source set.

## Data flow

```text
Android SAF picker
      |
      v
App-private temporary working file/folder
      |
      +--> NPAK v1 parser -> bounded payload streaming -> index/footer validation
      |                       |
      |                       +--> extract / replace / add / build
      |
      +--> Lua source editor -> optional local luac / unluac backend
      |
      v
Temporary output -> integrity checks -> replace/copy to user-selected destination
```

## Archive guarantees

- Index is bounded to 64 MiB and entry count to 1,000,000.
- Paths are relative and traversal components are rejected.
- Footer/index hashes and entry content hashes are verified.
- File payload operations use 64 KiB buffers.
- Output generation uses a temporary file and a same-directory replacement strategy.
- AES-GCM output is not accepted as valid plaintext until the authentication tag and SHA-256 check succeed.
- UI progress/cancellation checks run during local archive operations and SAF chunk-copy loops; an external document provider may still leave a partial destination if cancellation happens while copying to it.

## Known limitations

See `LIMITATIONS.md` and `NPAK_V1_FORMAT.md`. This project does not claim compatibility with proprietary archives. Lua compilation/decompilation backends are not bundled. The Android APK build was not verified in this offline environment.
