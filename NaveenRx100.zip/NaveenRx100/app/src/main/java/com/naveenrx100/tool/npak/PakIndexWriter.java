/*
 * NaveenRx100 Tool - Generic PakIndexWriter
 * EDUCATIONAL PURPOSE ONLY. Demonstrates serialization and validation of a synthetic archive index.
 * Not intended for illegal modification of any software.
 * Developer: NaveenRx100 | Credit: @NaveenRx100
 */
package com.naveenrx100.tool.npak;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Index codec for NPAK v1. The index is bounded to 64 MiB to avoid hostile allocations. */
public final class PakIndexWriter {
    public static final int MAX_INDEX_BYTES = 64 * 1024 * 1024;
    public static final int MAX_ENTRIES = 250_000;
    public static final int MAX_PATH_BYTES = 16 * 1024;
    public static final int FLAG_ENCRYPTED = 1;
    private static final byte[] MAGIC = new byte[]{'N','I','D','X'};
    private PakIndexWriter() {}

    public static final class Entry {
        public final String path; public final long offset, storedSize, originalSize; public final boolean encrypted; public final byte[] sha256;
        public Entry(String path,long offset,long storedSize,long originalSize,boolean encrypted,byte[] sha256) {
            this.path=normalizePath(path); if(this.path.isEmpty()) throw new IllegalArgumentException("Empty entry path");
            if(offset<8||storedSize<0||originalSize<0) throw new IllegalArgumentException("Invalid entry range or size");
            if(sha256==null||sha256.length!=32) throw new IllegalArgumentException("SHA-256 must be 32 bytes");
            this.offset=offset; this.storedSize=storedSize; this.originalSize=originalSize; this.encrypted=encrypted; this.sha256=sha256.clone();
        }
    }
    public static String normalizePath(String value) {
        if(value==null) throw new IllegalArgumentException("Path is null");
        String s=value.replace('\\','/').trim();
        while(s.startsWith("./")) s=s.substring(2);
        if(s.isEmpty()||s.startsWith("/")||s.matches("^[A-Za-z]:.*")) throw new IllegalArgumentException("Path must be relative: "+value);
        String[] parts=s.split("/",-1); StringBuilder out=new StringBuilder();
        for(String p:parts) { if(p.isEmpty()||".".equals(p)||"..".equals(p)) throw new IllegalArgumentException("Unsafe archive path: "+value); if(out.length()>0) out.append('/'); out.append(p); }
        String result=out.toString(); byte[] bytes=result.getBytes(StandardCharsets.UTF_8);
        if(bytes.length>MAX_PATH_BYTES) throw new IllegalArgumentException("Path is too long");
        return result;
    }
    public static byte[] serialize(List<Entry> entries) throws IOException {
        if(entries==null||entries.size()>MAX_ENTRIES) throw new IOException("Invalid entry list size");
        ByteArrayOutputStream bytes=new ByteArrayOutputStream(); DataOutputStream out=new DataOutputStream(bytes);
        out.write(MAGIC); writeU32(out,1); writeU32(out,entries.size()); Set<String> names=new HashSet<>();
        for(Entry e:entries) { if(e==null) throw new IOException("Null index entry"); String key=e.path.toLowerCase(java.util.Locale.ROOT); if(!names.add(key)) throw new IOException("Duplicate archive path: "+e.path);
            byte[] path=e.path.getBytes(StandardCharsets.UTF_8); writeU32(out,path.length); out.write(path); writeU64(out,e.offset); writeU64(out,e.storedSize); writeU64(out,e.originalSize); writeU32(out,e.encrypted?FLAG_ENCRYPTED:0); out.write(e.sha256);
            if(bytes.size()>MAX_INDEX_BYTES) throw new IOException("Index exceeds 64 MiB limit");
        }
        out.flush(); return bytes.toByteArray();
    }
    public static List<Entry> parse(byte[] data) throws IOException {
        if(data==null||data.length<12||data.length>MAX_INDEX_BYTES) throw new IOException("Invalid index length");
        DataInputStream in=new DataInputStream(new ByteArrayInputStream(data)); byte[] magic=new byte[4]; in.readFully(magic);
        if(!java.util.Arrays.equals(magic,MAGIC)) throw new IOException("Invalid NPAK index magic");
        long version=readU32(in), count=readU32(in); if(version!=1) throw new IOException("Unsupported NPAK index version: "+version); if(count>MAX_ENTRIES) throw new IOException("Entry count exceeds limit");
        List<Entry> result=new ArrayList<>((int)count); Set<String> names=new HashSet<>();
        try { for(int i=0;i<count;i++) { long pathLen=readU32(in); if(pathLen==0||pathLen>MAX_PATH_BYTES||pathLen>in.available()) throw new IOException("Invalid path length at entry "+i); byte[] pathBytes=new byte[(int)pathLen]; in.readFully(pathBytes); String path=new String(pathBytes,StandardCharsets.UTF_8); long offset=readU64(in), stored=readU64(in), original=readU64(in), flags=readU32(in); byte[] hash=new byte[32]; in.readFully(hash); if((flags&~FLAG_ENCRYPTED)!=0) throw new IOException("Unknown entry flags"); Entry e; try { e=new Entry(path,offset,stored,original,(flags&FLAG_ENCRYPTED)!=0,hash); } catch(IllegalArgumentException ex) { throw new IOException("Invalid entry "+i+": "+ex.getMessage(),ex); } if(!names.add(e.path.toLowerCase(java.util.Locale.ROOT))) throw new IOException("Duplicate path in index: "+e.path); result.add(e); } }
        catch(EOFException ex) { throw new IOException("Truncated index",ex); }
        if(in.available()!=0) throw new IOException("Trailing bytes after index entries"); return result;
    }
    private static void writeU32(DataOutputStream out,long n)throws IOException { if(n<0||n>0xffffffffL)throw new IOException("uint32 out of range"); for(int i=0;i<4;i++)out.writeByte((int)(n >>> (8*i))); }
    private static long readU32(DataInputStream in)throws IOException { long v=0; for(int i=0;i<4;i++)v|=((long)in.readUnsignedByte())<<(8*i); return v; }
    private static void writeU64(DataOutputStream out,long n)throws IOException { if(n<0)throw new IOException("uint64 exceeds signed Java range"); for(int i=0;i<8;i++)out.writeByte((int)(n >>> (8*i))); }
    private static long readU64(DataInputStream in)throws IOException { long v=0; for(int i=0;i<8;i++)v|=((long)in.readUnsignedByte())<<(8*i); if(v<0)throw new IOException("uint64 exceeds supported signed Java range"); return v; }
}
