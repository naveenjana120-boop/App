/*
 * NaveenRx100 Tool - Educational Module
 * EDUCATIONAL PURPOSE ONLY.
 * This code demonstrates Android development, local file handling, binary formats,
 * and cryptography for learning with files you own or are authorized to inspect.
 * Not intended for illegal modification of any software.
 * Developer: NaveenRx100 | Credit: @NaveenRx100
 */
package com.naveenrx100.tool.ui;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Toast;
import com.naveenrx100.tool.R;

public final class AboutActivity extends ToolScreenActivity {
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_about);
        NavHelper.bindToolbar(this, "About", "ℹ");
        NavHelper.bindBottomNav(this);
        findViewById(R.id.telegramButton).setOnClickListener(v -> {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(getString(R.string.telegram_link))));
            } catch (Exception e) {
                Toast.makeText(this, "Unable to open Telegram link.", Toast.LENGTH_LONG).show();
            }
        });
    }
}
