/*
 * NaveenRx100 Tool - Generic PakBuilder
 * EDUCATIONAL PURPOSE ONLY. Builds the documented synthetic NPAK v1 format.
 * Not intended for illegal modification of any software.
 * Developer: NaveenRx100 | Credit: @NaveenRx100
 */
package com.naveenrx100.tool.npak;

import java.io.File;
import java.io.IOException;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

/** Builds a fresh NPAK v1 archive from files in a directory. The template must also be NPAK v1. */
public final class PakBuilder {
    private PakBuilder(){}
    public static int buildNew(File template,File editDir,File output,PakRepacker.ProgressCallback cb,AtomicBoolean cancel)throws IOException {
        if(template==null||!template.isFile())throw new IOException("Template archive is missing");
        try(PakRepacker.Archive ignored=PakRepacker.open(template)) { return build(editDir,output,cb,cancel); }
    }
    public static int build(File editDir,File output,PakRepacker.ProgressCallback cb,AtomicBoolean cancel)throws IOException {
        java.util.Map<String,File> files=PakRepacker.scan(editDir);int total=files.size(),done=0;File parent=output.getAbsoluteFile().getParentFile();if(parent==null)throw new IOException("Output has no parent");if(!parent.isDirectory()&&!parent.mkdirs())throw new IOException("Cannot create output directory");File temp=File.createTempFile(".npak-build-", ".tmp",parent);boolean success=false;
        try(PakWriter writer=new PakWriter(temp)) {writer.writeBytes(new byte[]{'N','P','A','K',1,0,0,0});List<PakIndexWriter.Entry> entries=new ArrayList<>();
            for(java.util.Map.Entry<String,File> x:files.entrySet()){PakRepacker.check(cancel,cb);File f=x.getValue();long offset=writer.position();PakRepacker.copyFile(f,writer,cancel,cb);entries.add(new PakIndexWriter.Entry(x.getKey(),offset,f.length(),f.length(),false,PakRepacker.hashFile(f,cancel,cb)));done++;PakRepacker.progress(cb,done,total,"Adding "+x.getKey());}
            byte[] index=PakIndexWriter.serialize(entries);long indexOffset=writer.position();writer.writeBytes(index);writer.writeBytes(PakFooterWriter.serialize(indexOffset,index.length,entries.size(),index));writer.flush();writer.commit();success=true;PakWriter.atomicReplace(temp,output);PakRepacker.complete(cb,"Built NPAK with "+entries.size()+" file(s)");return done;
        } finally {if(temp.exists())temp.delete();}
    }
}
