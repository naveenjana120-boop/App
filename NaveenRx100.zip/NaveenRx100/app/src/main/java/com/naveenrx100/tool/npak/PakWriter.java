/*
 * NaveenRx100 Tool - Generic PakWriter
 * EDUCATIONAL PURPOSE ONLY. Demonstrates binary archive writing and streaming I/O.
 * Not intended for illegal modification of any software.
 * Developer: NaveenRx100 | Credit: @NaveenRx100
 */
package com.naveenrx100.tool.npak;

import java.io.BufferedOutputStream;
import java.io.Closeable;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.RandomAccessFile;

/** Streaming writer for the documented synthetic NPAK v1 format. */
public final class PakWriter implements Closeable {
    public interface CopyControl { boolean isCancelled(); }
    public static final int BUFFER_SIZE = 64 * 1024;
    private final File target;
    private final File temp;
    private final OutputStream out;
    private long position;
    private boolean closed;
    private boolean committed;

    public PakWriter(File target) throws IOException {
        if (target == null) throw new IllegalArgumentException("target is null");
        this.target = target.getAbsoluteFile();
        File parent = this.target.getParentFile();
        if (parent == null) throw new IOException("Output has no parent directory");
        if (!parent.isDirectory() && !parent.mkdirs()) throw new IOException("Cannot create output directory: " + parent);
        this.temp = File.createTempFile(".npak-", ".tmp", parent);
        this.out = new BufferedOutputStream(new FileOutputStream(temp), 256 * 1024);
    }
    public long position() { return position; }
    public File temporaryFile() { return temp; }
    public void writeByte(int value) throws IOException { ensureOpen(); out.write(value & 255); position++; }
    public void writeBytes(byte[] bytes) throws IOException { if (bytes == null) throw new IllegalArgumentException("bytes is null"); writeBytes(bytes, 0, bytes.length); }
    public void writeBytes(byte[] bytes, int offset, int length) throws IOException {
        ensureOpen(); if (bytes == null) throw new IllegalArgumentException("bytes is null");
        if (offset < 0 || length < 0 || offset > bytes.length - length) throw new IndexOutOfBoundsException();
        out.write(bytes, offset, length); position = Math.addExact(position, length);
    }
    public void writeUint32LE(long value) throws IOException {
        if (value < 0 || value > 0xffffffffL) throw new IllegalArgumentException("uint32 out of range");
        for (int i=0;i<4;i++) writeByte((int)(value >>> (8*i)));
    }
    public void writeInt32LE(int value) throws IOException { for (int i=0;i<4;i++) writeByte(value >>> (8*i)); }
    public void writeUint64LE(long value) throws IOException {
        if (value < 0) throw new IllegalArgumentException("uint64 value exceeds signed Java long range");
        for (int i=0;i<8;i++) writeByte((int)(value >>> (8*i)));
    }
    public void copyFrom(RandomAccessFile source, long offset, long length) throws IOException { copyFrom(source,offset,length,null); }
    public void copyFrom(RandomAccessFile source, long offset, long length, CopyControl control) throws IOException {
        ensureOpen(); if (source == null || offset < 0 || length < 0) throw new IllegalArgumentException("invalid source range");
        if (offset > source.length() || length > source.length() - offset) throw new IOException("Source range exceeds file length");
        source.seek(offset); byte[] buffer = new byte[BUFFER_SIZE]; long remaining=length;
        while (remaining>0) { int wanted=(int)Math.min(buffer.length,remaining); int n=source.read(buffer,0,wanted); if(n<0) throw new IOException("Unexpected EOF while copying archive data"); out.write(buffer,0,n); position=Math.addExact(position,n); remaining-=n; }
    }
    public void flush() throws IOException { ensureOpen(); out.flush(); }
    public void commit() throws IOException {
        ensureOpen(); out.flush(); out.close(); closed=true;
        try (FileOutputStream sync = new FileOutputStream(temp, true)) { sync.getFD().sync(); }
        atomicReplace(temp, target); committed=true;
    }
    public static File createTemp(File cacheDir, String prefix) throws IOException {
        File dir = cacheDir;
        if (dir == null) dir = new File(System.getProperty("java.io.tmpdir"));
        if (!dir.isDirectory() && !dir.mkdirs()) throw new IOException("Cannot create temp directory: " + dir);
        return File.createTempFile(prefix == null ? "npak-" : prefix, ".tmp", dir);
    }
    public static void atomicReplace(File temp, File target) throws IOException {
        if (temp == null || target == null || !temp.isFile()) throw new IOException("Temporary output is missing");
        File absoluteTarget=target.getAbsoluteFile(); File parent=absoluteTarget.getParentFile();
        if(parent==null || !parent.isDirectory()) throw new IOException("Output directory does not exist");
        File backup=null;
        if(absoluteTarget.exists()) {
            backup=File.createTempFile(".npak-backup-", ".tmp", parent);
            if(!backup.delete() || !absoluteTarget.renameTo(backup)) throw new IOException("Cannot preserve existing output before replacement");
        }
        if(!temp.renameTo(absoluteTarget)) {
            if(backup!=null) backup.renameTo(absoluteTarget);
            throw new IOException("Cannot move completed temp file into place");
        }
        if(backup!=null && backup.exists() && !backup.delete()) backup.deleteOnExit();
    }
    private void ensureOpen() throws IOException { if(closed) throw new IOException("Writer is closed"); }
    @Override public void close() throws IOException {
        if(!closed) { try { out.close(); } finally { closed=true; } }
        if(!committed && temp.exists() && !temp.delete()) temp.deleteOnExit();
    }
}
