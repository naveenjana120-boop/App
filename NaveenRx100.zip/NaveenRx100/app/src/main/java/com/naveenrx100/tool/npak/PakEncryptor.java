/*
 * NaveenRx100 Tool - Generic PakEncryptor
 * EDUCATIONAL PURPOSE ONLY. Demonstrates authenticated encryption for user-owned files.
 * Not intended for illegal modification of any software.
 * Developer: NaveenRx100 | Credit: @NaveenRx100
 */
package com.naveenrx100.tool.npak;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.security.GeneralSecurityException;
import java.security.MessageDigest;
import java.security.SecureRandom;
import javax.crypto.Cipher;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/** AES-GCM helpers. Stream encoding is nonce (12 bytes) followed by ciphertext and 128-bit tag. */
public final class PakEncryptor {
    private static final int NONCE_BYTES=12, TAG_BITS=128, BUFFER=64*1024;
    public interface StreamControl { boolean isCancelled(); }
    private PakEncryptor(){}
    public static byte[] encryptBytes(byte[] plaintext,byte[] key)throws GeneralSecurityException {
        if(plaintext==null)throw new IllegalArgumentException("plaintext is null");validateKey(key);byte[] nonce=new byte[NONCE_BYTES];new SecureRandom().nextBytes(nonce);Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.ENCRYPT_MODE,new SecretKeySpec(key,"AES"),new GCMParameterSpec(TAG_BITS,nonce));byte[] encrypted=c.doFinal(plaintext);byte[] result=new byte[nonce.length+encrypted.length];System.arraycopy(nonce,0,result,0,nonce.length);System.arraycopy(encrypted,0,result,nonce.length,encrypted.length);return result;
    }
    public static byte[] decryptBytes(byte[] encoded,byte[] key)throws GeneralSecurityException {
        if(encoded==null||encoded.length<NONCE_BYTES+16)throw new GeneralSecurityException("Encrypted data is too short");validateKey(key);byte[] nonce=new byte[NONCE_BYTES];System.arraycopy(encoded,0,nonce,0,NONCE_BYTES);Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.DECRYPT_MODE,new SecretKeySpec(key,"AES"),new GCMParameterSpec(TAG_BITS,nonce));return c.doFinal(encoded,NONCE_BYTES,encoded.length-NONCE_BYTES);
    }
    /** Encrypts with bounded memory and hashes the plaintext as it streams. Caller owns streams. Returns plaintext byte count. */
    public static long encryptStream(InputStream input,OutputStream output,byte[] key,MessageDigest plaintextDigest)throws IOException,GeneralSecurityException { return encryptStream(input,output,key,plaintextDigest,null); }
    public static long encryptStream(InputStream input,OutputStream output,byte[] key,MessageDigest plaintextDigest,StreamControl control)throws IOException,GeneralSecurityException {
        if(input==null||output==null)throw new IllegalArgumentException("streams must not be null");validateKey(key);byte[] nonce=new byte[NONCE_BYTES];new SecureRandom().nextBytes(nonce);output.write(nonce);Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.ENCRYPT_MODE,new SecretKeySpec(key,"AES"),new GCMParameterSpec(TAG_BITS,nonce));byte[] buffer=new byte[BUFFER];long count=0;int n;
        while(true){if(control!=null&&control.isCancelled())throw new IOException("Operation cancelled");n=input.read(buffer);if(n==-1)break;if(plaintextDigest!=null)plaintextDigest.update(buffer,0,n);count=Math.addExact(count,n);byte[] encrypted=cipher.update(buffer,0,n);if(encrypted!=null&&encrypted.length>0)output.write(encrypted);}
        byte[] last=cipher.doFinal();if(last.length>0)output.write(last);return count;
    }
    /** Decrypts a bounded region of a random-access file. Plaintext is written to a temporary output; caller must discard it if authentication fails. */
    public static long decryptRange(RandomAccessFile file,long offset,long length,OutputStream output,byte[] key,MessageDigest plaintextDigest)throws IOException,GeneralSecurityException { return decryptRange(file,offset,length,output,key,plaintextDigest,null); }
    public static long decryptRange(RandomAccessFile file,long offset,long length,OutputStream output,byte[] key,MessageDigest plaintextDigest,StreamControl control)throws IOException,GeneralSecurityException {
        if(file==null||output==null||offset<0||length<NONCE_BYTES+16||offset>file.length()||length>file.length()-offset)throw new IOException("Invalid encrypted file range");validateKey(key);file.seek(offset);byte[] nonce=new byte[NONCE_BYTES];file.readFully(nonce);Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.DECRYPT_MODE,new SecretKeySpec(key,"AES"),new GCMParameterSpec(TAG_BITS,nonce));byte[] buffer=new byte[BUFFER];long remaining=length-NONCE_BYTES,count=0;
        while(remaining>0){if(control!=null&&control.isCancelled())throw new IOException("Operation cancelled");int want=(int)Math.min(buffer.length,remaining);int n=file.read(buffer,0,want);if(n<0)throw new IOException("Truncated encrypted entry");remaining-=n;byte[] plain=cipher.update(buffer,0,n);if(plain!=null&&plain.length>0){output.write(plain);if(plaintextDigest!=null)plaintextDigest.update(plain);count=Math.addExact(count,plain.length);}}
        byte[] last=cipher.doFinal();if(last.length>0){output.write(last);if(plaintextDigest!=null)plaintextDigest.update(last);count=Math.addExact(count,last.length);}return count;
    }
    public static void validateKey(byte[] key){if(key==null||(key.length!=16&&key.length!=24&&key.length!=32))throw new IllegalArgumentException("AES key must be 16, 24, or 32 bytes");}
}
