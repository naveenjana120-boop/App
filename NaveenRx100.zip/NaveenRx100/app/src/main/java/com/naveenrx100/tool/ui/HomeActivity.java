/*
 * NaveenRx100 Tool - Educational Module
 * EDUCATIONAL PURPOSE ONLY.
 * This code demonstrates Android development, local file handling, binary formats,
 * and cryptography for learning with files you own or are authorized to inspect.
 * Not intended for illegal modification of any software.
 * Developer: NaveenRx100 | Credit: @NaveenRx100
 */
package com.naveenrx100.tool.ui;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import com.naveenrx100.tool.R;

public final class HomeActivity extends ToolScreenActivity {
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        TextView version = findViewById(R.id.homeVersion);
        if (version != null) version.setText(getString(R.string.version_label, getString(R.string.app_version)));
        NavHelper.bindBottomNav(this);
        View lua = findViewById(R.id.homeLuaCard);
        View pak = findViewById(R.id.homePakCard);
        if (lua != null) lua.setOnClickListener(v -> NavHelper.go(this, LuaToolsActivity.class));
        if (pak != null) pak.setOnClickListener(v -> NavHelper.go(this, PakToolsActivity.class));
    }
}
