/*
 * NaveenRx100 Tool - Generic PakRepacker
 * EDUCATIONAL PURPOSE ONLY. Demonstrates repacking a documented synthetic archive.
 * Not intended for illegal modification of any software.
 * Developer: NaveenRx100 | Credit: @NaveenRx100
 */
package com.naveenrx100.tool.npak;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;

/** Reader/extractor/repacker for NPAK v1 only. Archive data is copied in bounded chunks. */
public final class PakRepacker {
    public interface ProgressCallback { void onProgress(int current,int total,String message); void onComplete(String message); void onError(String message,Throwable error); boolean isCancelled(); }
    public static final class Archive implements Closeable {
        public final File file; public final PakFooterWriter.Footer footer; public final List<PakIndexWriter.Entry> entries;
        Archive(File f,PakFooterWriter.Footer ft,List<PakIndexWriter.Entry> es){file=f;footer=ft;entries=java.util.Collections.unmodifiableList(es);}
        @Override public void close(){}
    }
    private PakRepacker(){}
    public static Archive open(File file)throws IOException {
        if(file==null||!file.isFile())throw new IOException("Archive not found");
        try(RandomAccessFile raf=new RandomAccessFile(file,"r")) {
            PakFooterWriter.Footer footer=PakFooterWriter.parse(raf);byte[] index=readRange(raf,footer.indexOffset,footer.indexLength);List<PakIndexWriter.Entry> entries=PakIndexWriter.parse(index);
            if(entries.size()!=footer.entryCount)throw new IOException("Footer entry count does not match index");
            List<PakIndexWriter.Entry> ranges=new ArrayList<>(entries);ranges.sort(Comparator.comparingLong(e->e.offset));long previousEnd=8;
            for(PakIndexWriter.Entry e:ranges){if(e.offset<previousEnd||e.offset>footer.indexOffset||e.storedSize>footer.indexOffset-e.offset)throw new IOException("Entry data ranges overlap or extend beyond data section: "+e.path);previousEnd=Math.max(previousEnd,e.offset+e.storedSize);}
            return new Archive(file,footer,new ArrayList<>(entries));
        }
    }
    public static List<PakIndexWriter.Entry> inspect(File file)throws IOException { try(Archive a=open(file)){return new ArrayList<>(a.entries);} }
    public static int extractAll(File source,File outputDir,byte[] encryptionKey,ProgressCallback cb,AtomicBoolean cancel)throws IOException {
        Archive a=open(source);if(outputDir==null)throw new IOException("Output directory is null");if(!outputDir.exists()&&!outputDir.mkdirs())throw new IOException("Cannot create extraction directory");File root=outputDir.getCanonicalFile();String rootPrefix=root.getCanonicalPath()+File.separator;int total=a.entries.size(),done=0;
        try(RandomAccessFile raf=new RandomAccessFile(source,"r")) {
            for(PakIndexWriter.Entry e:a.entries){check(cancel,cb);File out=new File(root,e.path).getCanonicalFile();if(!out.getCanonicalPath().startsWith(rootPrefix))throw new IOException("Unsafe output path: "+e.path);File parent=out.getParentFile();if(!parent.isDirectory()&&!parent.mkdirs())throw new IOException("Cannot create output directory for "+e.path);
                File temp=File.createTempFile(".npak-extract-", ".tmp",parent);boolean ok=false;
                try { try(FileOutputStream fos=new FileOutputStream(temp)){raf.seek(e.offset);byte[] buffer=new byte[PakWriter.BUFFER_SIZE];long remaining=e.storedSize;MessageDigest digest=sha256Digest();
                        if(e.encrypted){try{PakEncryptor.decryptRange(raf,e.offset,e.storedSize,fos,encryptionKey,digest,()->(cancel!=null&&cancel.get())||(cb!=null&&cb.isCancelled()));}catch(Exception ex){if(ex instanceof IOException&&"Operation cancelled".equals(ex.getMessage()))throw(IOException)ex;throw new IOException("Cannot decrypt "+e.path+" (key required or invalid)",ex);}}
                        else {while(remaining>0){check(cancel,cb);int want=(int)Math.min(buffer.length,remaining);int n=raf.read(buffer,0,want);if(n<0)throw new IOException("Truncated entry: "+e.path);fos.write(buffer,0,n);digest.update(buffer,0,n);remaining-=n;}}
                        fos.getFD().sync();if(!MessageDigest.isEqual(digest.digest(),e.sha256))throw new IOException("Content SHA-256 mismatch: "+e.path);
                    }
                    PakWriter.atomicReplace(temp,out);ok=true;
                } finally {if(!ok&&temp.exists())temp.delete();}
                done++;progress(cb,done,total,"Extracted "+e.path);
            }
        }
        complete(cb,"Extracted "+done+" file(s)");return done;
    }
    public static int repack(File source,File editedRoot,File output,boolean forceAdd,Map<String,String> pathMap,ProgressCallback cb,AtomicBoolean cancel)throws IOException {
        Archive archive=open(source);Map<String,PakIndexWriter.Entry> original=new LinkedHashMap<>();for(PakIndexWriter.Entry e:archive.entries)original.put(key(e.path),e);
        Map<String,File> edits=scan(editedRoot);Map<String,File> selected=new LinkedHashMap<>();Map<String,String> names=new LinkedHashMap<>();
        for(Map.Entry<String,File> x:edits.entrySet()){String path=x.getKey();if(pathMap!=null&&pathMap.containsKey(path))path=pathMap.get(path);path=PakIndexWriter.normalizePath(path);if(selected.put(key(path),x.getValue())!=null)throw new IOException("Multiple edited files map to "+path);names.put(key(path),path);}
        Set<String> applicable=new HashSet<>();for(String k:selected.keySet())if(original.containsKey(k)||forceAdd)applicable.add(k);
        int total=archive.entries.size();for(String k:applicable)if(!original.containsKey(k))total++;int done=0;
        File parent=output.getAbsoluteFile().getParentFile();if(parent==null)throw new IOException("Output has no parent");if(!parent.isDirectory()&&!parent.mkdirs())throw new IOException("Cannot create output directory");File temp=File.createTempFile(".npak-repack-", ".tmp",parent);boolean committed=false;
        try(PakWriter writer=new PakWriter(temp);RandomAccessFile src=new RandomAccessFile(source,"r")) {
            writer.writeBytes(new byte[]{'N','P','A','K',1,0,0,0});List<PakIndexWriter.Entry> newEntries=new ArrayList<>();Set<String> consumed=new HashSet<>();
            for(PakIndexWriter.Entry e:archive.entries){check(cancel,cb);File replacement=selected.get(key(e.path));long offset=writer.position();if(replacement!=null&&applicable.contains(key(e.path))){copyFile(replacement,writer,cancel,cb);newEntries.add(new PakIndexWriter.Entry(e.path,offset,replacement.length(),replacement.length(),false,hashFile(replacement,cancel,cb)));consumed.add(key(e.path));}
                else {writer.copyFrom(src,e.offset,e.storedSize,()->(cancel!=null&&cancel.get())||(cb!=null&&cb.isCancelled()));newEntries.add(new PakIndexWriter.Entry(e.path,offset,e.storedSize,e.originalSize,e.encrypted,e.sha256));}
                done++;progress(cb,done,total,"Repacked "+e.path);
            }
            for(String k:applicable){if(original.containsKey(k)||consumed.contains(k))continue;check(cancel,cb);File f=selected.get(k);long offset=writer.position();copyFile(f,writer,cancel,cb);newEntries.add(new PakIndexWriter.Entry(names.get(k),offset,f.length(),f.length(),false,hashFile(f,cancel,cb)));done++;progress(cb,done,total,"Added "+names.get(k));}
            byte[] index=PakIndexWriter.serialize(newEntries);long indexOffset=writer.position();writer.writeBytes(index);writer.writeBytes(PakFooterWriter.serialize(indexOffset,index.length,newEntries.size(),index));writer.flush();writer.commit();committed=true;
            // PakWriter writes to temp; replace the user output atomically after a complete archive is closed.
            PakWriter.atomicReplace(temp,output);complete(cb,"Repacked "+newEntries.size()+" file(s)");return done;
        } catch(Throwable t){if(t instanceof IOException)throw(IOException)t;if(t instanceof RuntimeException)throw(RuntimeException)t;throw new IOException("Repack failed",t);} finally {if(!committed&&temp.exists())temp.delete();if(temp.exists())temp.delete();}
    }
    public static int repack(File source,File editedRoot,File output,boolean forceAdd,ProgressCallback cb)throws IOException{return repack(source,editedRoot,output,forceAdd,null,cb,new AtomicBoolean(false));}
    static Map<String,File> scan(File root)throws IOException {if(root==null||!root.isDirectory())throw new IOException("Edit folder does not exist");Map<String,File> out=new java.util.TreeMap<>();scanRec(root,root,out);return out;}
    private static void scanRec(File root,File dir,Map<String,File> out)throws IOException {File[] files=dir.listFiles();if(files==null)throw new IOException("Cannot list directory: "+dir);Arrays.sort(files,Comparator.comparing(File::getName,String.CASE_INSENSITIVE_ORDER));for(File f:files){if(f.isDirectory())scanRec(root,f,out);else if(f.isFile()){String rel=root.getCanonicalFile().toURI().relativize(f.getCanonicalFile().toURI()).getPath();String path=PakIndexWriter.normalizePath(rel);if(out.put(path,f)!=null)throw new IOException("Duplicate edit path: "+path);}}}
    static void copyFile(File file,PakWriter writer,AtomicBoolean cancel,ProgressCallback cb)throws IOException {try(InputStream in=new BufferedInputStream(new FileInputStream(file))){byte[] b=new byte[PakWriter.BUFFER_SIZE];int n;while((n=in.read(b))!=-1){check(cancel,cb);writer.writeBytes(b,0,n);}}}
    static byte[] hashFile(File f,AtomicBoolean cancel,ProgressCallback cb)throws IOException {MessageDigest d=sha256Digest();try(InputStream in=new FileInputStream(f)){byte[] b=new byte[PakWriter.BUFFER_SIZE];int n;while((n=in.read(b))!=-1){check(cancel,cb);d.update(b,0,n);}}return d.digest();}
    static byte[] readRange(RandomAccessFile raf,long off,long len)throws IOException {if(len<0||len>PakIndexWriter.MAX_INDEX_BYTES||len>Integer.MAX_VALUE)throw new IOException("Index exceeds safe parsing limit");byte[] b=new byte[(int)len];raf.seek(off);raf.readFully(b);return b;}
    static MessageDigest sha256Digest()throws IOException {try{return MessageDigest.getInstance("SHA-256");}catch(Exception e){throw new IOException(e);}}
    static void check(AtomicBoolean cancel,ProgressCallback cb)throws IOException {if((cancel!=null&&cancel.get())||(cb!=null&&cb.isCancelled()))throw new IOException("Operation cancelled");}
    static void progress(ProgressCallback cb,int done,int total,String msg){if(cb!=null)cb.onProgress(done,total,msg);}
    static void complete(ProgressCallback cb,String msg){if(cb!=null)cb.onComplete(msg);}
    private static String key(String s){return s.toLowerCase(Locale.ROOT);}
}
