/*
 * NaveenRx100 Tool - Educational Module
 * EDUCATIONAL PURPOSE ONLY.
 * This code demonstrates Android development, local file handling, binary formats,
 * and cryptography for learning with files you own or are authorized to inspect.
 * Not intended for illegal modification of any software.
 * Developer: NaveenRx100 | Credit: @NaveenRx100
 */
package com.naveenrx100.tool.ui;

import android.app.AlertDialog;
import android.os.Bundle;
import com.naveenrx100.tool.R;

public final class HelpActivity extends ToolScreenActivity {
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_help);
        NavHelper.bindToolbar(this, "Help", "?");
        NavHelper.bindBottomNav(this);
        findViewById(R.id.faqFileAccess).setOnClickListener(v -> faq("File access", "Use the Android document picker. Grant access only to files and folders you own or are authorized to inspect."));
        findViewById(R.id.faqLua).setOnClickListener(v -> faq("Lua tools", "Edit standard Lua source locally. Compilation requires a compatible Lua 5.3 compiler; decompilation requires a compatible unluac.jar."));
        findViewById(R.id.faqPak).setOnClickListener(v -> faq("PAK tools", "This build supports only the documented synthetic NPAK v1 format. It does not read proprietary game archives."));
        findViewById(R.id.faqInject).setOnClickListener(v -> faq("Inject tool", "The Inject screen is informational only. Live process injection, game modification, and anti-cheat bypass are not implemented."));
    }
    private void faq(String title, String text) {
        new AlertDialog.Builder(this).setTitle(title).setMessage(text).setPositiveButton("OK", null).show();
    }
}
