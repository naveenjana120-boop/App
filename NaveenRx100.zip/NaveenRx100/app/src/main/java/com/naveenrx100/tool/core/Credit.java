package com.naveenrx100.tool.core;

public final class Credit {
    private Credit() {}
    public static final String TOOL_NAME = "NaveenRx100 UNLIMITED LUA TOOL";
    public static final String DEVELOPER = "NaveenRx100";
    public static final String OWNER = "NaveenRx100";
    public static final String CREDIT = "@NaveenRx100";
    public static final String TELEGRAM_LINK = "https://t.me/+POQQ4JunAG9hMWM1";
    public static final String VERSION = "1.0.0";
    public static final String EDUCATION_DISCLAIMER =
            "This app is for EDUCATIONAL PURPOSE ONLY. Use it to learn Android development, binary formats, cryptography, and authorized local-file handling. Do not use it to bypass protections, modify online games, or access files without permission. The Inject Tool is informational only and does not inject into live games.";
}
