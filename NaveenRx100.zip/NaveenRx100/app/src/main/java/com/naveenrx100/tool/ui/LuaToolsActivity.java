/*
 * NaveenRx100 Tool - Generic Lua Tools UI
 * EDUCATIONAL PURPOSE ONLY. Handles standard Lua source and optional local tool backends.
 * Not intended for illegal modification of any software.
 * Developer: NaveenRx100 | Credit: @NaveenRx100
 */
package com.naveenrx100.tool.ui;

import android.app.AlertDialog;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.content.Intent;
import android.net.Uri;
import com.naveenrx100.tool.R;
import com.naveenrx100.tool.core.LuaCompiler;
import com.naveenrx100.tool.core.LuaDecompiler;
import com.naveenrx100.tool.core.SafFileBridge;
import com.naveenrx100.tool.core.StdLuaFormat;
import java.io.File;
import java.nio.charset.StandardCharsets;

/** Standard Lua source editor with honest optional compiler/decompiler support. */
public final class LuaToolsActivity extends ToolScreenActivity {
    private static final int REQUEST_SAVE_BYTECODE=2112;
    private String sourceText="";
    private byte[] pendingBytecode;
    private EditText editor;
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);setContentView(R.layout.activity_lua_tools);NavHelper.bindToolbar(this,"Lua Tools","</>");NavHelper.bindBottomNav(this);
        findViewById(R.id.rowOpenLua).setOnClickListener(v->openDocument("*/*",REQUEST_OPEN_LUA));
        findViewById(R.id.rowScriptEditor).setOnClickListener(v->showEditor());
        findViewById(R.id.rowCompileLua).setOnClickListener(v->compileCurrent());
        findViewById(R.id.rowLuaViewer).setOnClickListener(v->showCurrent());
    }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){super.onActivityResult(requestCode,resultCode,data);if(resultCode!=RESULT_OK||data==null||data.getData()==null)return;Uri uri=data.getData();try{
        if(requestCode==REQUEST_OPEN_LUA){File file=SafFileBridge.copyUriToCache(this,uri,"lua-open-");try{if(file.length()>32L*1024*1024)throw new java.io.IOException("Lua file exceeds 32 MiB inspection limit");byte[] bytes=com.naveenrx100.tool.core.FileHelper.readAllBytes(file);if(StdLuaFormat.hasSignature(bytes)){File jar=new File(getFilesDir(),"unluac.jar");LuaDecompiler.Result r=LuaDecompiler.decompile(bytes,this,jar);if(r.decompiled){sourceText=r.text;Toast.makeText(this,"Bytecode decompiled with local backend.",Toast.LENGTH_LONG).show();showEditor();}else{String details="Standard Lua bytecode detected. Version byte: 0x"+String.format(java.util.Locale.ROOT,"%02X",bytes.length>4?bytes[4]&255:0)+"\n"+r.message+"\n\nPlace a compatible unluac.jar in app-private files to enable decompilation.";showMessage("Lua bytecode",details);}}else{sourceText=new String(bytes,StandardCharsets.UTF_8);showEditor();}}finally{file.delete();}}
        else if(requestCode==REQUEST_CREATE_LUA){SafFileBridge.writeText(this,uri,sourceText);Toast.makeText(this,"Lua source saved.",Toast.LENGTH_LONG).show();}
        else if(requestCode==REQUEST_SAVE_BYTECODE){if(pendingBytecode==null)throw new java.io.IOException("No compiled bytecode is available");try(java.io.OutputStream out=getContentResolver().openOutputStream(uri,"wt")){if(out==null)throw new java.io.IOException("Cannot open output document");out.write(pendingBytecode);out.flush();}Toast.makeText(this,"Bytecode saved.",Toast.LENGTH_LONG).show();pendingBytecode=null;}
    }catch(Exception e){showMessage("Lua operation failed",e.getMessage()==null?e.getClass().getSimpleName():e.getMessage());}}
    private void showEditor(){editor=new EditText(this);editor.setGravity(Gravity.TOP|Gravity.START);editor.setMinLines(12);editor.setTextSize(14);editor.setTypeface(android.graphics.Typeface.MONOSPACE);editor.setHint("-- Enter standard Lua source here");editor.setText(sourceText);ScrollView scroll=new ScrollView(this);scroll.addView(editor);new AlertDialog.Builder(this).setTitle("Lua Source Editor").setView(scroll).setNegativeButton("Close",null).setNeutralButton("Save As",(d,w)->{sourceText=editor.getText().toString();createDocument("text/plain","script.lua",REQUEST_CREATE_LUA);}).setPositiveButton("Keep",(d,w)->{sourceText=editor.getText().toString();Toast.makeText(this,"Source retained in editor.",Toast.LENGTH_SHORT).show();}).show();}
    private void compileCurrent(){if(editor!=null)sourceText=editor.getText().toString();File luac=new File(getFilesDir(),"luac");LuaCompiler.Result result=LuaCompiler.compile(sourceText,luac,getCacheDir(),false);if(!result.compiled){showMessage("Lua compiler unavailable",result.message+"\n\nA compatible Lua 5.3 compiler executable must be installed/configured in app-private storage. No fake bytecode was generated.");return;}pendingBytecode=result.bytecode;createDocument("application/octet-stream","script.luac",REQUEST_SAVE_BYTECODE);}
    private void showCurrent(){if(sourceText==null||sourceText.isEmpty()){showMessage("Lua Viewer","Open a Lua source or bytecode file first.");return;}showMessage("Lua Viewer",sourceText.length()>12000?sourceText.substring(0,12000)+"\n… (preview truncated)":sourceText);}
    private void showMessage(String title,String message){TextView text=new TextView(this);text.setText(message==null?"Unknown error":message);text.setTextIsSelectable(true);text.setPadding(24,16,24,16);new AlertDialog.Builder(this).setTitle(title).setView(text).setPositiveButton("OK",null).show();}
}
