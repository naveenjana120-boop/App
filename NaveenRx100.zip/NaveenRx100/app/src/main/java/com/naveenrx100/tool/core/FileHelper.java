/*
 * NaveenRx100 Tool - Educational Module
 * EDUCATIONAL PURPOSE ONLY.
 * This code demonstrates Android development, local file handling, binary formats,
 * and cryptography for learning with files you own or are authorized to inspect.
 * Not intended for illegal modification of any software.
 * Developer: NaveenRx100 | Credit: @NaveenRx100
 */
package com.naveenrx100.tool.core;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

public final class FileHelper {
    private FileHelper() {}

    public static byte[] readAllBytes(File file) throws IOException {
        if (file == null || !file.isFile()) throw new IOException("Input file does not exist: " + file);
        if (file.length() > Integer.MAX_VALUE) throw new IOException("File is too large for a byte array");
        try (BufferedInputStream in = new BufferedInputStream(new FileInputStream(file))) {
            java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream((int) file.length());
            byte[] buffer = new byte[8192];
            int count;
            while ((count = in.read(buffer)) != -1) out.write(buffer, 0, count);
            return out.toByteArray();
        }
    }

    public static void writeAllBytes(File file, byte[] data) throws IOException {
        if (file == null) throw new IOException("Output file is null");
        if (data == null) throw new IOException("Output data is null");
        File parent = file.getAbsoluteFile().getParentFile();
        if (parent != null) ensureDir(parent);
        try (BufferedOutputStream out = new BufferedOutputStream(new FileOutputStream(file))) {
            out.write(data);
            out.flush();
        }
    }

    public static boolean ensureDir(File dir) throws IOException {
        if (dir == null) throw new IOException("Directory is null");
        if (dir.isDirectory()) return true;
        if (dir.exists()) throw new IOException("Path exists but is not a directory: " + dir);
        if (!dir.mkdirs() && !dir.isDirectory()) throw new IOException("Could not create directory: " + dir);
        return true;
    }

    public static void copyFile(File source, File destination) throws IOException {
        if (source == null || !source.isFile()) throw new IOException("Source file does not exist: " + source);
        if (destination == null) throw new IOException("Destination is null");
        if (source.getCanonicalFile().equals(destination.getCanonicalFile())) return;
        File parent = destination.getAbsoluteFile().getParentFile();
        if (parent != null) ensureDir(parent);
        try (BufferedInputStream in = new BufferedInputStream(new FileInputStream(source));
             BufferedOutputStream out = new BufferedOutputStream(new FileOutputStream(destination))) {
            byte[] buffer = new byte[8192];
            int count;
            while ((count = in.read(buffer)) != -1) out.write(buffer, 0, count);
            out.flush();
        }
    }

    public static String humanSize(long bytes) {
        if (bytes < 0) return "Unknown";
        if (bytes < 1024L) return bytes + " B";
        double size = bytes;
        String[] units = {"KB", "MB", "GB", "TB"};
        int unit = -1;
        do { size /= 1024.0; unit++; } while (size >= 1024.0 && unit < units.length - 1);
        return String.format(Locale.US, "%.2f %s", size, units[unit]);
    }

    /** Sanitizes a single path component for safe filesystem output. */
    public static String sanitizePart(String name) {
        if (name == null) return "_";
        String s = name.replace("\u0000", "");
        s = s.replaceAll("[\\x00-\\x1f<>:\"/\\\\|?*\\x7f]", "");
        s = s.replaceFirst("[. ]+$", "");
        if (s.isEmpty() || s.equals(".") || s.equals("..")) return "_";
        return s;
    }

    public static String _sanitize_part(String name) { return sanitizePart(name); }

    public static String sanitizeFilename(String name) {
        if (name == null || name.trim().isEmpty()) return "unnamed";
        String cleaned = name.replace('\\', '_').replace('/', '_')
                .replaceAll("[\\u0000-\\u001F<>:\"|?*]", "_")
                .trim();
        while (cleaned.equals(".") || cleaned.equals("..")) cleaned = "_" + cleaned;
        if (cleaned.length() > 180) {
            int dot = cleaned.lastIndexOf('.');
            String extension = dot > 0 && cleaned.length() - dot <= 16 ? cleaned.substring(dot) : "";
            String stem = extension.isEmpty() ? cleaned : cleaned.substring(0, dot);
            cleaned = stem.substring(0, Math.min(stem.length(), 180 - extension.length())) + extension;
        }
        return cleaned.isEmpty() ? "unnamed" : cleaned;
    }

    public static List<File> listFilesByExtension(File directory, String... extensions) {
        if (directory == null || !directory.isDirectory()) return Collections.emptyList();
        final List<String> normalized = new ArrayList<>();
        if (extensions != null) for (String ext : extensions) {
            if (ext != null && !ext.trim().isEmpty()) {
                String e = ext.trim().toLowerCase(Locale.ROOT);
                normalized.add(e.startsWith(".") ? e : "." + e);
            }
        }
        File[] children = directory.listFiles();
        if (children == null) return Collections.emptyList();
        List<File> result = new ArrayList<>();
        for (File file : children) {
            if (!file.isFile()) continue;
            String lower = file.getName().toLowerCase(Locale.ROOT);
            for (String ext : normalized) if (lower.endsWith(ext)) { result.add(file); break; }
        }
        Collections.sort(result, Comparator.comparing(File::getName, String.CASE_INSENSITIVE_ORDER));
        return result;
    }
}
