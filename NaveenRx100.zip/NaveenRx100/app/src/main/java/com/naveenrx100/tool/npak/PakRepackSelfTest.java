/*
 * NaveenRx100 Tool - Generic PakRepackSelfTest
 * EDUCATIONAL PURPOSE ONLY. Tests only synthetic NPAK v1 files.
 * Not intended for illegal modification of any software.
 * Developer: NaveenRx100 | Credit: @NaveenRx100
 */
package com.naveenrx100.tool.npak;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

/** Repeatable integration tests that run without Android APIs or proprietary archive samples. */
public final class PakRepackSelfTest {
    private PakRepackSelfTest(){}
    public static final class Result { public final boolean passed; public final String report; Result(boolean p,String r){passed=p;report=r;} }
    public static Result run(File workDir) {
        StringBuilder report=new StringBuilder();File root=null;
        try {
            if(workDir==null)root=new File(System.getProperty("java.io.tmpdir"),"npak-selftest-"+System.nanoTime());else root=new File(workDir,"npak-selftest-"+System.nanoTime());
            if(!root.mkdirs())throw new IOException("Cannot create self-test directory");File input=new File(root,"input");if(!input.mkdirs())throw new IOException("Cannot create input directory");
            write(new File(input,"hello.txt"),"hello NPAK\n".getBytes(StandardCharsets.UTF_8));byte[] large=new byte[8*1024*1024];for(int i=0;i<large.length;i++)large[i]=(byte)(i*31);write(new File(input,"large.bin"),large);
            File archive=new File(root,"sample.npak");int built=PakBuilder.build(input,archive,null,new AtomicBoolean(false));assertTrue(built==2,"initial build entry count");report.append("PASS: build synthetic archive (2 entries)\n");
            List<PakIndexWriter.Entry> listed=PakRepacker.inspect(archive);assertTrue(listed.size()==2,"index parse count");report.append("PASS: parse index and footer\n");
            File noEdits=new File(root,"no-edits");if(!noEdits.mkdirs())throw new IOException("Cannot create no-edits folder");File noChange=new File(root,"no-change.npak");PakRepacker.repack(archive,noEdits,noChange,false,null,null,new AtomicBoolean(false));try(PakRepacker.Archive a=PakRepacker.open(archive);PakRepacker.Archive b=PakRepacker.open(noChange)){assertTrue(MessageDigest.isEqual(a.footer.indexSha256,b.footer.indexSha256),"no-change repack index hash");}report.append("PASS: no-change repack preserves index hash\n");
            File extracted=new File(root,"extract");int extractedCount=PakRepacker.extractAll(archive,extracted,null,null,new AtomicBoolean(false));assertTrue(extractedCount==2,"extract count");assertTrue(Arrays.equals(large,read(new File(extracted,"large.bin"))),"large streaming payload SHA/content");report.append("PASS: extract and verify 8 MiB payload\n");
            File edits=new File(root,"edits");if(!edits.mkdirs())throw new IOException("Cannot create edits folder");write(new File(edits,"hello.txt"),"edited content\n".getBytes(StandardCharsets.UTF_8));write(new File(edits,"new.txt"),"new file\n".getBytes(StandardCharsets.UTF_8));File repacked=new File(root,"repacked.npak");int n=PakRepacker.repack(archive,edits,repacked,true,null,null,new AtomicBoolean(false));assertTrue(n==3,"repack processed count");assertTrue(PakRepacker.inspect(repacked).size()==3,"repack entry count");report.append("PASS: replace and add files\n");
            File injectSource=new File(root,"inject.txt");write(injectSource,"encrypted payload".getBytes(StandardCharsets.UTF_8));byte[] key=new byte[16];Arrays.fill(key,(byte)7);List<InjectItem> plan=new ArrayList<>();plan.add(new InjectItem("secure/data.txt",injectSource,key));plan.add(new InjectItem("secure/large.bin",new File(input,"large.bin"),key));File injected=new File(root,"injected.npak");assertTrue(PakInjector.inject(repacked,plan,injected,null,new AtomicBoolean(false))==2,"inject count");
            File extracted2=new File(root,"extract2");try{PakRepacker.extractAll(injected,extracted2,null,null,new AtomicBoolean(false));throw new AssertionError("encrypted extraction should require key");}catch(IOException expected){assertTrue(expected.getMessage().contains("Cannot decrypt")||expected.getCause()!=null,"expected encryption failure");}
            File extractedEncrypted=new File(root,"extract-encrypted");PakRepacker.extractAll(injected,extractedEncrypted,key,null,new AtomicBoolean(false));assertTrue(Arrays.equals("encrypted payload".getBytes(StandardCharsets.UTF_8),read(new File(extractedEncrypted,"secure/data.txt"))),"encrypted injected file decrypts and verifies");assertTrue(Arrays.equals(large,read(new File(extractedEncrypted,"secure/large.bin"))),"8 MiB encrypted stream round trip");report.append("PASS: AES-GCM encrypted entries (including 8 MiB streaming payload) decrypt and verify\n");
            byte[] roundTrip=PakEncryptor.decryptBytes(PakEncryptor.encryptBytes("crypto test".getBytes(StandardCharsets.UTF_8),key),key);assertTrue(new String(roundTrip,StandardCharsets.UTF_8).equals("crypto test"),"AES-GCM roundtrip");report.append("PASS: AES-GCM authenticated encryption round trip\n");
            boolean unsafeRejected=false;try{PakIndexWriter.normalizePath("../escape.txt");}catch(IllegalArgumentException expected){unsafeRejected=true;}assertTrue(unsafeRejected,"path traversal rejection");report.append("PASS: path traversal rejected\n");
            File cancelledOutput=new File(root,"cancelled.npak");byte[] sentinel="keep existing output".getBytes(StandardCharsets.UTF_8);write(cancelledOutput,sentinel);boolean cancelRejected=false;try{PakRepacker.repack(archive,new File(root,"no-edits"),cancelledOutput,false,null,null,new AtomicBoolean(true));}catch(IOException expected){cancelRejected=expected.getMessage().contains("cancelled");}assertTrue(cancelRejected,"cancellation handling");assertTrue(Arrays.equals(sentinel,read(cancelledOutput)),"cancel preserves existing output");report.append("PASS: cancellation stops repack and preserves existing output\n");
            byte[] bad=read(archive);bad[bad.length-1]^=1;File corrupt=new File(root,"corrupt.npak");write(corrupt,bad);try{PakRepacker.open(corrupt);throw new AssertionError("corruption should fail");}catch(IOException expected){report.append("PASS: corrupt footer/index rejected\n");}
            report.append("RESULT: 15 assertions passed, 0 failed\n");return new Result(true,report.toString());
        } catch(Throwable t){report.append("FAIL: ").append(t.getClass().getSimpleName()).append(": ").append(t.getMessage()).append('\n');return new Result(false,report.toString());}
        finally { if(root!=null&&root.exists())deleteRec(root); }
    }
    private static void assertTrue(boolean ok,String name){if(!ok)throw new AssertionError(name);}
    private static void write(File f,byte[] b)throws IOException{File p=f.getParentFile();if(p!=null&&!p.isDirectory()&&!p.mkdirs())throw new IOException("Cannot create directory");try(FileOutputStream out=new FileOutputStream(f)){out.write(b);out.getFD().sync();}}
    private static byte[] read(File f)throws IOException{if(f.length()>Integer.MAX_VALUE)throw new IOException("Test file too large");try(java.io.FileInputStream in=new java.io.FileInputStream(f);java.io.ByteArrayOutputStream out=new java.io.ByteArrayOutputStream((int)f.length())){byte[] b=new byte[8192];int n;while((n=in.read(b))!=-1)out.write(b,0,n);return out.toByteArray();}}
    private static void deleteRec(File f){File[] children=f.listFiles();if(children!=null)for(File c:children)deleteRec(c);f.delete();}
}
