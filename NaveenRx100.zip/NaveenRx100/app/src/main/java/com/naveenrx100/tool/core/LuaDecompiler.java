/*
 * NaveenRx100 Tool - Educational Module
 * EDUCATIONAL PURPOSE ONLY.
 * This code demonstrates Android development, local file handling, binary formats,
 * and cryptography for learning with files you own or are authorized to inspect.
 * Not intended for illegal modification of any software.
 * Developer: NaveenRx100 | Credit: @NaveenRx100
 */
package com.naveenrx100.tool.core;

import android.content.Context;
import dalvik.system.DexClassLoader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.PrintStream;
import java.io.ByteArrayOutputStream;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;

/** Best-effort local decompiler bridge. Raw bytecode is always preserved on failure. */
public final class LuaDecompiler {
    public static final class Result {
        public final boolean decompiled; public final String text; public final byte[] bytecode; public final String message;
        Result(boolean d,String t,byte[] b,String m){decompiled=d;text=t;bytecode=b==null?null:b.clone();message=m;}
    }
    private LuaDecompiler() {}
    public static Result decompile(byte[] bytecode, Context context, File unluacJar) {
        if(bytecode==null) return new Result(false,"",null,"No bytecode supplied");
        if(context==null || unluacJar==null || !unluacJar.isFile()) return new Result(false,"",bytecode,"unluac.jar unavailable; raw bytecode retained");
        File cache=context.getCodeCacheDir(); File input=null, output=null;
        try {
            input=File.createTempFile("lua-decompile-", ".luac", context.getCacheDir());
            output=File.createTempFile("lua-decompile-", ".txt", context.getCacheDir());
            try(FileOutputStream fos=new FileOutputStream(input)){fos.write(bytecode);}
            DexClassLoader loader=new DexClassLoader(unluacJar.getAbsolutePath(),cache.getAbsolutePath(),null,context.getClassLoader());
            Class<?> main=loader.loadClass("unluac.Main");
            // unluac is commonly a command-line Java archive. If the patched build exposes main(String[]), capture is build-dependent.
            Method method=main.getMethod("main",String[].class);
            ByteArrayOutputStream captured=new ByteArrayOutputStream();
            synchronized (LuaDecompiler.class) {
                PrintStream previous=System.out;
                try (PrintStream capture=new PrintStream(captured,true,"UTF-8")) {
                    System.setOut(capture);
                    method.invoke(null,(Object)new String[]{input.getAbsolutePath()});
                } finally { System.setOut(previous); }
            }
            String result=captured.toString("UTF-8");
            if(result.trim().isEmpty() && output.isFile()) result=new String(readAll(output),StandardCharsets.UTF_8);
            if(result.trim().isEmpty()) return new Result(false,"",bytecode,"Decompiler produced no source text; raw bytecode retained");
            return new Result(true,result,bytecode,"Decompiled");
        } catch(Throwable ex){ return new Result(false,"",bytecode,"Decompilation unavailable: "+rootMessage(ex)); }
        finally { if(input!=null) input.delete(); if(output!=null) output.delete(); }
    }
    private static byte[] readAll(File f) throws Exception { try(InputStream in=new java.io.FileInputStream(f); java.io.ByteArrayOutputStream out=new java.io.ByteArrayOutputStream()){byte[] b=new byte[8192];int n;while((n=in.read(b))!=-1)out.write(b,0,n);return out.toByteArray();} }
    private static String rootMessage(Throwable t){while(t.getCause()!=null)t=t.getCause();String m=t.getMessage();return m==null?t.getClass().getSimpleName():m;}
}
