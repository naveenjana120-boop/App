/*
 * NaveenRx100 Tool - Educational Module
 * EDUCATIONAL PURPOSE ONLY.
 * This code demonstrates Android development, local file handling, binary formats,
 * and cryptography for learning with files you own or are authorized to inspect.
 * Not intended for illegal modification of any software.
 * Developer: NaveenRx100 | Credit: @NaveenRx100
 */
package com.naveenrx100.tool.core;

import android.os.Bundle;
import com.naveenrx100.tool.ui.NavHelper;
import com.naveenrx100.tool.ui.ToolScreenActivity;

/** Optional common base for screens that use the shared toolbar and bottom navigation layouts. */
public abstract class BaseToolActivity extends ToolScreenActivity {
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Logger.init(getApplicationContext());
    }

    protected final void configureCommonNavigation(String title, String icon) {
        NavHelper.bindToolbar(this, title, icon);
        NavHelper.bindBottomNav(this);
    }

    protected final void logScreenOpened(String title) {
        Logger.log("Opened screen: " + title);
    }
}
