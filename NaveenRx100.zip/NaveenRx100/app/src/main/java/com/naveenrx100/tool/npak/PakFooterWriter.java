/*
 * NaveenRx100 Tool - Generic PakFooterWriter
 * EDUCATIONAL PURPOSE ONLY. Demonstrates footer serialization and archive integrity checks.
 * Not intended for illegal modification of any software.
 * Developer: NaveenRx100 | Credit: @NaveenRx100
 */
package com.naveenrx100.tool.npak;

import java.io.IOException;
import java.io.RandomAccessFile;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;

/** Footer codec for synthetic NPAK v1. Footer size is 72 bytes. */
public final class PakFooterWriter {
    public static final int FOOTER_SIZE=72;
    private static final byte[] MAGIC={'N','P','A','K','E','N','D','1'};
    public static final class Footer { public final long indexOffset,indexLength; public final int entryCount; public final byte[] indexSha256; Footer(long o,long l,int c,byte[] h){indexOffset=o;indexLength=l;entryCount=c;indexSha256=h;} }
    private PakFooterWriter(){}
    public static byte[] serialize(long offset,long length,int count,byte[] index) throws IOException {
        if(offset<8||length<12||count<0||count>PakIndexWriter.MAX_ENTRIES)throw new IOException("Invalid footer values");
        if(index==null||index.length!=length)throw new IOException("Index length mismatch"); byte[] hash=sha256(index); byte[] out=new byte[FOOTER_SIZE]; int p=0;
        System.arraycopy(MAGIC,0,out,p,8);p+=8;put32(out,p,1);p+=4;put32(out,p,0);p+=4;put64(out,p,offset);p+=8;put64(out,p,length);p+=8;put32(out,p,count);p+=4;put32(out,p,0);p+=4;System.arraycopy(hash,0,out,p,32);return out;
    }
    public static Footer parse(RandomAccessFile file)throws IOException {
        long length=file.length(); if(length<8+FOOTER_SIZE)throw new IOException("File is too short to be an NPAK archive");
        byte[] header=new byte[8];file.seek(0);file.readFully(header);if(!Arrays.equals(header,new byte[]{'N','P','A','K',1,0,0,0}))throw new IOException("Invalid NPAK v1 header");
        byte[] b=new byte[FOOTER_SIZE];file.seek(length-FOOTER_SIZE);file.readFully(b);int p=0;byte[] magic=Arrays.copyOfRange(b,0,8);p=8;if(!Arrays.equals(magic,MAGIC))throw new IOException("Invalid NPAK footer magic");long version=get32(b,p);p+=4;long flags=get32(b,p);p+=4;long offset=get64(b,p);p+=8;long idxLen=get64(b,p);p+=8;long count=get32(b,p);p+=4;long reserved=get32(b,p);p+=4;byte[] hash=Arrays.copyOfRange(b,p,p+32);
        if(version!=1||flags!=0||reserved!=0)throw new IOException("Unsupported NPAK footer fields"); if(count>PakIndexWriter.MAX_ENTRIES||idxLen>PakIndexWriter.MAX_INDEX_BYTES||idxLen<12)throw new IOException("Footer sizes exceed limits"); long footerStart=length-FOOTER_SIZE;if(offset<8||offset>footerStart||idxLen>footerStart-offset||offset+idxLen!=footerStart)throw new IOException("Invalid index range");
        byte[] index=new byte[(int)idxLen];file.seek(offset);file.readFully(index);if(!MessageDigest.isEqual(hash,sha256(index)))throw new IOException("Index SHA-256 mismatch");return new Footer(offset,idxLen,(int)count,hash);
    }
    public static byte[] sha256(byte[] b)throws IOException {try{return MessageDigest.getInstance("SHA-256").digest(b);}catch(NoSuchAlgorithmException e){throw new IOException(e);}}
    private static void put32(byte[] b,int p,long v){for(int i=0;i<4;i++)b[p+i]=(byte)(v >>> (8*i));}
    private static void put64(byte[] b,int p,long v){for(int i=0;i<8;i++)b[p+i]=(byte)(v >>> (8*i));}
    private static long get32(byte[] b,int p){long v=0;for(int i=0;i<4;i++)v|=((long)b[p+i]&255)<<(8*i);return v;}
    private static long get64(byte[] b,int p)throws IOException{long v=0;for(int i=0;i<8;i++)v|=((long)b[p+i]&255)<<(8*i);if(v<0)throw new IOException("Unsigned offset exceeds supported range");return v;}
}
