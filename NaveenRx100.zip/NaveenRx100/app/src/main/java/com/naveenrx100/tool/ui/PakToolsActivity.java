/*
 * NaveenRx100 Tool - Generic PAK Tools UI
 * EDUCATIONAL PURPOSE ONLY. This screen works with synthetic NPAK v1 archives only.
 * Not intended for illegal modification of any software.
 * Developer: NaveenRx100 | Credit: @NaveenRx100
 */
package com.naveenrx100.tool.ui;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import com.naveenrx100.tool.R;
import com.naveenrx100.tool.core.SafFileBridge;
import com.naveenrx100.tool.npak.InjectItem;
import com.naveenrx100.tool.npak.PakBuilder;
import com.naveenrx100.tool.npak.PakInjector;
import com.naveenrx100.tool.npak.PakOperations;
import com.naveenrx100.tool.npak.PakRepacker;
import java.io.File;
import java.io.IOException;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/** SAF-based UI for the generic NPAK v1 learning format. */
public final class PakToolsActivity extends ToolScreenActivity {
    private static final int REQUEST_EXTRACT_TREE=2105, REQUEST_EDIT_TREE=2106, REQUEST_INJECT_FILE=2107,
            REQUEST_INJECT_OUTPUT=2108, REQUEST_BUILD_TREE=2110, REQUEST_BUILD_OUTPUT=2111;
    private final Handler main=new Handler(Looper.getMainLooper());
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private final AtomicBoolean cancel=new AtomicBoolean(false);
    private File currentPak, editedDirectory, pendingInjectFile;
    private ProgressDialog progress;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);setContentView(R.layout.activity_pak_tools);NavHelper.bindToolbar(this,"Generic PAK Tools","📦");NavHelper.bindBottomNav(this);
        findViewById(R.id.rowOpenPak).setOnClickListener(v->openDocument("*/*",REQUEST_OPEN_PAK));
        findViewById(R.id.rowExtractPak).setOnClickListener(v->chooseExtractFolder());
        findViewById(R.id.rowRepackPak).setOnClickListener(v->chooseEditFolder(REQUEST_EDIT_TREE));
        findViewById(R.id.rowPakViewer).setOnClickListener(v->showEntries());
        View build=findViewById(R.id.rowBuildPak);if(build!=null)build.setOnClickListener(v->chooseEditFolder(REQUEST_BUILD_TREE));
        View inject=findViewById(R.id.rowInjectPak);if(inject!=null)inject.setOnClickListener(v->{if(requirePak())openDocument("*/*",REQUEST_INJECT_FILE);});
        View test=findViewById(R.id.rowPakSelfTest);if(test!=null)test.setOnClickListener(v->runSelfTest());
    }
    private boolean requirePak(){if(currentPak==null||!currentPak.isFile()){Toast.makeText(this,"Open a valid NPAK v1 file first.",Toast.LENGTH_LONG).show();return false;}return true;}
    private void chooseExtractFolder(){if(!requirePak())return;openTree(REQUEST_EXTRACT_TREE);}
    private void chooseEditFolder(int code){if(!requirePak())return;openTree(code);}
    private void openTree(int code){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);try{startActivityForResult(i,code);}catch(Exception e){Toast.makeText(this,"Folder picker is unavailable.",Toast.LENGTH_LONG).show();}}
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){super.onActivityResult(requestCode,resultCode,data);if(resultCode!=RESULT_OK||data==null||data.getData()==null){if(requestCode==REQUEST_CREATE_PAK||requestCode==REQUEST_BUILD_OUTPUT){deleteRec(editedDirectory);editedDirectory=null;}if(requestCode==REQUEST_INJECT_OUTPUT){if(pendingInjectFile!=null)pendingInjectFile.delete();pendingInjectFile=null;}return;}Uri uri=data.getData();
        try {
            if(requestCode==REQUEST_OPEN_PAK){runJob("Opening NPAK",(flag,cb)->{File selected=SafFileBridge.copyUriToCache(this,uri,"npak-open-",()->flag.get()||cb.isCancelled());try{PakRepacker.inspect(selected);main.post(()->{if(currentPak!=null&&!currentPak.equals(selected))currentPak.delete();currentPak=selected;showEntries();});return "Archive opened";}catch(Exception e){selected.delete();throw e;}});}
            else if(requestCode==REQUEST_EXTRACT_TREE){File archive=currentPak;runJob("Extracting NPAK",(flag,cb)->{File temp=new File(getCacheDir(),"npak-extract-"+System.nanoTime());try{PakOperations.extractAll(archive,temp,null,cb,flag);SafFileBridge.copyDirectoryToTree(this,temp,uri,()->flag.get()||cb.isCancelled());return "Extraction complete";}finally{deleteRec(temp);}});}
            else if(requestCode==REQUEST_EDIT_TREE||requestCode==REQUEST_BUILD_TREE){final int outputRequest=requestCode==REQUEST_BUILD_TREE?REQUEST_BUILD_OUTPUT:REQUEST_CREATE_PAK;final String suggested=requestCode==REQUEST_BUILD_TREE?"new-archive.npak":"repacked.npak";runJob("Preparing selected folder",(flag,cb)->{File dir=new File(getCacheDir(),"npak-edit-"+System.nanoTime());SafFileBridge.copyTreeToDirectory(this,uri,dir,()->flag.get()||cb.isCancelled());main.post(()->{editedDirectory=dir;createDocument("application/octet-stream",suggested,outputRequest);});return "Folder ready";});}
            else if(requestCode==REQUEST_CREATE_PAK){File archive=currentPak,edits=editedDirectory;File out=File.createTempFile("npak-output-", ".npak",getCacheDir());runJob("Repacking NPAK",(flag,cb)->{try{PakOperations.repack(archive,edits,out,true,cb,flag);SafFileBridge.copyFileToUri(this,out,uri,()->flag.get()||cb.isCancelled());return "Repack completed";}finally{out.delete();deleteRec(edits);}});}
            else if(requestCode==REQUEST_INJECT_FILE){runJob("Importing file",(flag,cb)->{File imported=SafFileBridge.copyUriToCache(this,uri,"npak-inject-",()->flag.get()||cb.isCancelled());main.post(()->{pendingInjectFile=imported;showInjectPathDialog();});return "Input file ready";});}
            else if(requestCode==REQUEST_INJECT_OUTPUT){File archive=currentPak,src=pendingInjectFile;File out=File.createTempFile("npak-inject-output-", ".npak",getCacheDir());runJob("Adding file",(flag,cb)->{try{PakInjector.inject(archive,Collections.singletonList(new InjectItem(pendingInjectPath,src)),out,cb,flag);SafFileBridge.copyFileToUri(this,out,uri,()->flag.get()||cb.isCancelled());return "File added";}finally{out.delete();if(src!=null)src.delete();pendingInjectFile=null;}});}
            else if(requestCode==REQUEST_BUILD_OUTPUT){File template=currentPak,edits=editedDirectory;File out=File.createTempFile("npak-build-output-", ".npak",getCacheDir());runJob("Building NPAK",(flag,cb)->{try{PakBuilder.buildNew(template,edits,out,cb,flag);SafFileBridge.copyFileToUri(this,out,uri,()->flag.get()||cb.isCancelled());return "Build complete";}finally{out.delete();deleteRec(edits);}});}
        } catch(Exception e){showError("Operation failed",e);}
    }
    private String pendingInjectPath;
    private void showInjectPathDialog(){EditText path=new EditText(this);path.setSingleLine(true);path.setHint("internal/path/name.bin");new AlertDialog.Builder(this).setTitle("Archive path").setMessage("Choose a relative path inside your synthetic NPAK archive.").setView(path).setNegativeButton("Cancel",(d,w)->{if(pendingInjectFile!=null)pendingInjectFile.delete();pendingInjectFile=null;}).setPositiveButton("Continue",(d,w)->{String p=path.getText().toString().trim();try{pendingInjectPath=com.naveenrx100.tool.npak.PakIndexWriter.normalizePath(p);createDocument("application/octet-stream","injected.npak",REQUEST_INJECT_OUTPUT);}catch(Exception ex){showError("Invalid archive path",ex);}}).show();}
    private void showEntries(){if(currentPak==null){Toast.makeText(this,"Open a synthetic NPAK v1 archive first.",Toast.LENGTH_SHORT).show();return;}try{List<com.naveenrx100.tool.npak.PakIndexWriter.Entry> entries=PakRepacker.inspect(currentPak);StringBuilder b=new StringBuilder("NPAK v1 • ").append(entries.size()).append(" entries\n\n");int shown=0;for(com.naveenrx100.tool.npak.PakIndexWriter.Entry e:entries){if(shown++>=200)break;b.append(e.path).append("\n  stored: ").append(e.storedSize).append(" bytes; original: ").append(e.originalSize).append(e.encrypted?"; AES-GCM":"").append("\n");}if(entries.size()>200)b.append("\n… and ").append(entries.size()-200).append(" more entries");new AlertDialog.Builder(this).setTitle("Archive Viewer").setMessage(b.toString()).setPositiveButton("OK",null).show();}catch(Exception e){showError("Cannot read archive",e);}}
    private void runSelfTest(){runJob("Synthetic NPAK self-test",(flag,cb)->{com.naveenrx100.tool.npak.PakRepackSelfTest.Result r=com.naveenrx100.tool.npak.PakRepackSelfTest.run(getCacheDir());if(!r.passed)throw new IOException(r.report);main.post(()->new AlertDialog.Builder(this).setTitle("Self-test passed").setMessage(r.report).setPositiveButton("OK",null).show());return r.report;});}
    private interface Job{String run(AtomicBoolean cancel,PakOperations.Callback callback)throws Exception;}
    private void runJob(String title,Job job){cancel.set(false);progress=new ProgressDialog(this);progress.setTitle(title);progress.setMessage("Starting…");progress.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);progress.setMax(100);progress.setCancelable(false);progress.setButton(ProgressDialog.BUTTON_NEGATIVE,"Cancel",(d,w)->cancel.set(true));progress.show();worker.execute(()->{String result="";Throwable error=null;PakOperations.Callback cb=new PakOperations.Callback(){public void onProgress(int c,int t,String m){if(t>0){int pct=(int)(100L*c/t);main.post(()->{if(progress!=null&&progress.isShowing()){progress.setProgress(pct);progress.setMessage(m);}});}}public void onComplete(String m){}public void onError(String m,Throwable t){}public boolean isCancelled(){return cancel.get();}};try{result=job.run(cancel,cb);}catch(Throwable t){error=t;}final String msg=result;final Throwable failure=error;main.post(()->{if(progress!=null&&progress.isShowing())progress.dismiss();progress=null;if(failure==null)Toast.makeText(this,msg==null?"Completed":msg,Toast.LENGTH_LONG).show();else showError("Operation failed",failure);});});}
    private void showError(String title,Throwable e){new AlertDialog.Builder(this).setTitle(title).setMessage(e.getMessage()==null?e.getClass().getSimpleName():e.getMessage()).setPositiveButton("OK",null).show();}
    private static void deleteRec(File f){if(f==null||!f.exists())return;File[] children=f.listFiles();if(children!=null)for(File c:children)deleteRec(c);f.delete();}
    @Override protected void onDestroy(){cancel.set(true);super.onDestroy();worker.shutdownNow();if(progress!=null&&progress.isShowing())progress.dismiss();}
}
