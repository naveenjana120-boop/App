/*
 * NaveenRx100 Tool - Generic PakInjector
 * EDUCATIONAL PURPOSE ONLY. Adds files to a synthetic NPAK v1 archive.
 * Not intended for illegal modification of any software.
 * Developer: NaveenRx100 | Credit: @NaveenRx100
 */
package com.naveenrx100.tool.npak;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;

/** Appends generic user-owned files to NPAK v1 and rebuilds the index/footer. */
public final class PakInjector {
    private PakInjector(){}

    public static int inject(File source,List<InjectItem> items,File output,PakRepacker.ProgressCallback cb,AtomicBoolean cancel)throws IOException {
        if(items==null||items.isEmpty())throw new IOException("No files were supplied for injection");PakRepacker.Archive a=PakRepacker.open(source);Set<String> names=new HashSet<>();for(PakIndexWriter.Entry e:a.entries)names.add(e.path.toLowerCase(Locale.ROOT));
        for(InjectItem item:items){if(item==null||!item.sourceFile.isFile())throw new IOException("An input file is missing");if(!names.add(item.internalPath.toLowerCase(Locale.ROOT)))throw new IOException("Archive path already exists: "+item.internalPath);}
        File parent=output.getAbsoluteFile().getParentFile();if(parent==null)throw new IOException("Output has no parent");if(!parent.isDirectory()&&!parent.mkdirs())throw new IOException("Cannot create output directory");File temp=File.createTempFile(".npak-inject-", ".tmp",parent);int total=a.entries.size()+items.size(),done=0;
        try(PakWriter writer=new PakWriter(temp);RandomAccessFile src=new RandomAccessFile(source,"r")) {
            writer.writeBytes(new byte[]{'N','P','A','K',1,0,0,0});List<PakIndexWriter.Entry> entries=new ArrayList<>();
            for(PakIndexWriter.Entry e:a.entries){PakRepacker.check(cancel,cb);long off=writer.position();writer.copyFrom(src,e.offset,e.storedSize,()->(cancel!=null&&cancel.get())||(cb!=null&&cb.isCancelled()));entries.add(new PakIndexWriter.Entry(e.path,off,e.storedSize,e.originalSize,e.encrypted,e.sha256));done++;PakRepacker.progress(cb,done,total,"Copying "+e.path);}
            for(InjectItem item:items){PakRepacker.check(cancel,cb);long off=writer.position();byte[] hash;
                if(item.encrypted()){java.security.MessageDigest digest=PakRepacker.sha256Digest();try(java.io.InputStream in=new java.io.BufferedInputStream(new java.io.FileInputStream(item.sourceFile))){java.io.OutputStream sink=new java.io.OutputStream(){@Override public void write(int b)throws IOException{writer.writeByte(b);}@Override public void write(byte[] b,int o,int l)throws IOException{writer.writeBytes(b,o,l);}};long plainSize=PakEncryptor.encryptStream(in,sink,item.encryptionKey,digest,()->(cancel!=null&&cancel.get())||(cb!=null&&cb.isCancelled()));long stored=writer.position()-off;entries.add(new PakIndexWriter.Entry(item.internalPath,off,stored,plainSize,true,digest.digest()));}catch(Exception e){if(e instanceof IOException&&"Operation cancelled".equals(e.getMessage()))throw(IOException)e;throw new IOException("Encryption failed for "+item.internalPath,e);}}
                else {PakRepacker.copyFile(item.sourceFile,writer,cancel,cb);hash=PakRepacker.hashFile(item.sourceFile,cancel,cb);entries.add(new PakIndexWriter.Entry(item.internalPath,off,item.sourceFile.length(),item.sourceFile.length(),false,hash));}
                done++;PakRepacker.progress(cb,done,total,"Adding "+item.internalPath);
            }
            byte[] index=PakIndexWriter.serialize(entries);long indexOff=writer.position();writer.writeBytes(index);writer.writeBytes(PakFooterWriter.serialize(indexOff,index.length,entries.size(),index));writer.flush();writer.commit();PakWriter.atomicReplace(temp,output);PakRepacker.complete(cb,"Added "+items.size()+" file(s)");return items.size();
        } finally {if(temp.exists())temp.delete();}
    }
}
