/*
 * NaveenRx100 Tool - Educational Module
 * EDUCATIONAL PURPOSE ONLY.
 * This code demonstrates Android development, local file handling, binary formats,
 * and cryptography for learning with files you own or are authorized to inspect.
 * Not intended for illegal modification of any software.
 * Developer: NaveenRx100 | Credit: @NaveenRx100
 */
package com.naveenrx100.tool.core;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/** Local Lua 5.3 compiler bridge. Uses a configured luac executable; otherwise returns a clear raw-source fallback. */
public final class LuaCompiler {
    public static final class Result {
        public final boolean compiled; public final byte[] bytecode; public final String message;
        Result(boolean ok,byte[] bytes,String msg){compiled=ok;bytecode=bytes==null?null:bytes.clone();message=msg;}
    }
    private LuaCompiler() {}
    public static Result compile(String source, File luacExecutable, File workingDirectory, boolean stripDebug) {
        if(source==null) return new Result(false,null,"Source is null");
        if(luacExecutable==null || !luacExecutable.isFile() || !luacExecutable.canExecute())
            return new Result(false,source.getBytes(StandardCharsets.UTF_8),"Lua 5.3 luac executable is unavailable; UTF-8 source returned instead of fabricated bytecode");
        File work=workingDirectory!=null?workingDirectory:new File(System.getProperty("java.io.tmpdir"));
        if(!work.exists() && !work.mkdirs()) return new Result(false,source.getBytes(StandardCharsets.UTF_8),"Cannot create compiler working directory");
        File in=null,out=null;
        try {
            in=File.createTempFile("lua-src-", ".lua",work); out=File.createTempFile("lua-out-", ".luac",work);
            try(FileOutputStream fos=new FileOutputStream(in)){fos.write(source.getBytes(StandardCharsets.UTF_8));}
            List<String> command=new ArrayList<>(); command.add(luacExecutable.getAbsolutePath()); if(stripDebug) command.add("-s"); command.add("-o");command.add(out.getAbsolutePath());command.add(in.getAbsolutePath());
            Process process=new ProcessBuilder(command).directory(work).redirectErrorStream(true).start();
            byte[] log=readAll(process.getInputStream()); int exit=process.waitFor();
            if(exit!=0 || !out.isFile() || out.length()==0) return new Result(false,source.getBytes(StandardCharsets.UTF_8),"luac failed (exit "+exit+"): "+new String(log,StandardCharsets.UTF_8));
            byte[] bytes=readAll(new java.io.FileInputStream(out));
            if(!StdLuaFormat.hasSignature(bytes)) return new Result(false,source.getBytes(StandardCharsets.UTF_8),"Compiler output is not Lua bytecode");
            return new Result(true,bytes,"Compiled successfully");
        } catch(Exception ex){return new Result(false,source.getBytes(StandardCharsets.UTF_8),"Compilation unavailable: "+ex.getMessage());}
        finally {if(in!=null)in.delete();if(out!=null)out.delete();}
    }
    private static byte[] readAll(InputStream in) throws java.io.IOException {try(InputStream src=in;ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[] b=new byte[8192];int n;while((n=src.read(b))!=-1)out.write(b,0,n);return out.toByteArray();}}
}
