/*
 * NaveenRx100 Tool - PakRepacker
 *
 * EDUCATIONAL PURPOSE ONLY
 * This code demonstrates binary file format analysis,
 * archive writing, and cryptography for learning purposes.
 *
 * Not intended for illegal modification of any software.
 *
 * Developer: NaveenRx100
 * Credit: @NaveenRx100
 */
package com.naveenrx100.tool.pak;

import com.github.luben.zstd.Zstd;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Port of HXE.py's {@code repack_pak_file_full}.
 *
 * <p>Reads the source PAK, produces a new PAK where edited files are replaced
 * and (optionally) new files are appended at target paths. Uses streaming
 * copy from the source file; the entire PAK is never loaded into RAM.</p>
 */
public final class PakRepacker {

    public interface ProgressCallback {
        void onFile(int processed, int total, String path);
        void onStage(String stage);
        boolean isCancelled();
    }

    private PakRepacker() {}

    // ---------------------------------------------------------------
    // Public entry point — mirrors HXE.py repack_pak_file_full
    // ---------------------------------------------------------------
    public static int repack(TencentPakFile pak,
                             File editedRoot,
                             File outputPak,
                             String targetPath,
                             boolean forceAdd,
                             Map<String, String> pathMap,
                             ProgressCallback cb) throws IOException {

        List<File> editFiles = listFilesRecursive(editedRoot);
        if (editFiles.isEmpty()) {
            return 0;
        }

        int version = pak.version();
        int[] keystream = PakCrypto.zucKeystream();

        // Read directory table + mount point from the original index.
        DirectoryListing listing = pak.readDirectoryListing();
        String mountPoint = listing.mountPoint();
        LinkedHashMap<String, LinkedHashMap<String, EntryRef>> allDirs = listing.dirs();

        // Normalize target path.
        if (targetPath != null) {
            targetPath = normalizeDir(targetPath, allDirs);
        }
        Map<String, String> normalizedPathMap = new HashMap<>();
        if (pathMap != null) {
            for (Map.Entry<String, String> e : pathMap.entrySet()) {
                normalizedPathMap.put(e.getKey(), normalizeDir(e.getValue(), allDirs));
            }
        }

        // Basename → list of (fullPath, slot, entry) candidates.
        Map<String, List<EntryRef>> pakNameMap = new HashMap<>();
        for (Map.Entry<String, LinkedHashMap<String, EntryRef>> de : allDirs.entrySet()) {
            String dpStr = de.getKey();
            for (Map.Entry<String, EntryRef> fe : de.getValue().entrySet()) {
                String name = fe.getKey();
                EntryRef ref = fe.getValue();
                String fullPath = joinPath(dpStr, name).replace('\\', '/');
                pakNameMap.computeIfAbsent(name.toLowerCase(Locale.ROOT),
                        k -> new ArrayList<>()).add(new EntryRef(fullPath, ref.slot, ref.entry));
            }
        }

        // Match each edit file to an existing entry (or mark as new).
        LinkedHashMap<String, EditSlot> edits = new LinkedHashMap<>();
        for (File p : editFiles) {
            matchFile(p, editedRoot, allDirs, pakNameMap, targetPath,
                    normalizedPathMap, forceAdd, edits);
        }
        if (edits.isEmpty()) return 0;

        if (cb != null) cb.onStage("Writing new PAK");

        // Open RandomAccessFile for streaming source reads.
        try (RandomAccessFile srcRaf = new RandomAccessFile(pak.sourcePath(), "r");
             PakWriter w = new PakWriter(outputPak, srcRaf)) {

            // Copy original entries (with edits applied) in directory order.
            // We build a "slotToNew" map.
            int originalEntryCount = listing.entries().size();
            TencentPakEntry[] slotToNew = new TencentPakEntry[originalEntryCount];
            for (int i = 0; i < originalEntryCount; i++) {
                slotToNew[i] = copyOf(listing.entries().get(i));
            }

            List<NewEntry> newAdded = new ArrayList<>();
            List<String[]> fileRows = new ArrayList<>();

            int total = countTotalEntries(allDirs);
            int done = 0;

            for (Map.Entry<String, LinkedHashMap<String, EntryRef>> de : allDirs.entrySet()) {
                String dpStr = de.getKey();
                for (Map.Entry<String, EntryRef> fe : de.getValue().entrySet()) {
                    if (cb != null && cb.isCancelled()) {
                        throw new IOException("Cancelled");
                    }
                    String name = fe.getKey();
                    EntryRef ref = fe.getValue();
                    String fullPath = joinPath(dpStr, name).replace('\\', '/');

                    TencentPakEntry ne = slotToNew[ref.slot];
                    EditSlot es = edits.get(fullPath);

                    if (es != null && !es.isNew) {
                        // Replace with new content.
                        writeEditedEntry(w, srcRaf, ne, es.file, fullPath,
                                ref.entry, pak.zstdDict());
                        fileRows.add(new String[]{fullPath,
                                Long.toString(es.file.length()),
                                Long.toString(ne.size())});
                    } else {
                        // Copy unchanged entry.
                        copyEntry(w, srcRaf, ne, ref.entry);
                    }

                    done++;
                    if (cb != null) cb.onFile(done, total, fullPath);
                }
            }

            // Append new files (only when forceAdd or the entry is genuinely new).
            if (forceAdd) {
                for (Map.Entry<String, EditSlot> ee : edits.entrySet()) {
                    EditSlot es = ee.getValue();
                    if (!es.isNew || es.template == null) continue;
                    String fp = ee.getKey();

                    // Skip if it already exists in allDirs (we would have set isNew=false).
                    boolean exists = false;
                    for (LinkedHashMap<String, EntryRef> dir : allDirs.values()) {
                        for (String n : dir.keySet()) {
                            String pth = joinPath("", n);
                            // cheap basename check
                            if (n.equals(es.file.getName()) && fp.endsWith("/" + n)) {
                                exists = true;
                                break;
                            }
                        }
                        if (exists) break;
                    }
                    if (exists) continue;

                    TencentPakEntry ne = copyOf(es.template);
                    writeNewEntry(w, ne, es.file, fp, mountPoint, pak.zstdDict());
                    newAdded.add(new NewEntry(es.dirKey, es.file.getName(), ne));
                    fileRows.add(new String[]{fp,
                            Long.toString(es.file.length()),
                            Long.toString(ne.size())});
                }
            }

            // Assemble final entry list.
            List<TencentPakEntry> newFiles = new ArrayList<>(slotToNew.length + newAdded.size());
            for (TencentPakEntry e : slotToNew) newFiles.add(e);
            // dir_to_added
            LinkedHashMap<String, List<NewEntry>> dirToAdded = new LinkedHashMap<>();
            for (NewEntry na : newAdded) {
                newFiles.add(na.entry);
                na.slot = newFiles.size() - 1;
                dirToAdded.computeIfAbsent(na.dirKey, k -> new ArrayList<>()).add(na);
            }
            // Extend allDirs.
            for (Map.Entry<String, List<NewEntry>> de : dirToAdded.entrySet()) {
                String dk = de.getKey();
                LinkedHashMap<String, EntryRef> target =
                        allDirs.computeIfAbsent(dk, k -> new LinkedHashMap<>());
                for (NewEntry na : de.getValue()) {
                    target.put(na.name, new EntryRef("", na.slot, na.entry));
                }
            }

            // Build directory table (name → entry index).
            LinkedHashMap<String, LinkedHashMap<String, Integer>> dirTable = new LinkedHashMap<>();
            for (Map.Entry<String, LinkedHashMap<String, EntryRef>> de : allDirs.entrySet()) {
                LinkedHashMap<String, Integer> inner = new LinkedHashMap<>();
                for (Map.Entry<String, EntryRef> fe : de.getValue().entrySet()) {
                    inner.put(fe.getKey(), fe.getValue().slot);
                }
                dirTable.put(de.getKey(), inner);
            }

            if (cb != null) cb.onStage("Serializing index");

            byte[] indexPlain = PakIndexWriter.serialize(mountPoint, newFiles, dirTable, version);
            byte[] indexSha1 = sha1(indexPlain);
            byte[] indexEncrypted = PakEncryptor.encryptIndex(indexPlain, pak.pakInfo());

            long newIndexOffset = w.position();
            w.writeBytes(indexEncrypted);
            long newIndexSize = indexEncrypted.length;

            // Footer: copy original and patch last 36 bytes.
            byte[] footerTemplate = pak.readOriginalFooterBytes();
            PakFooterWriter.patchFooter(footerTemplate, indexSha1,
                    newIndexSize, newIndexOffset, keystream);
            w.writeBytes(footerTemplate);

            w.commit();
            return edits.size();
        }
    }

    // ---------------------------------------------------------------
    // Helpers
    // ---------------------------------------------------------------

    private static void matchFile(File p,
                                  File editedRoot,
                                  LinkedHashMap<String, LinkedHashMap<String, EntryRef>> allDirs,
                                  Map<String, List<EntryRef>> pakNameMap,
                                  String targetPath,
                                  Map<String, String> pathMap,
                                  boolean forceAdd,
                                  LinkedHashMap<String, EditSlot> edits) throws IOException {
        String fl = p.getName().toLowerCase(Locale.ROOT);

        // 1) Relative path lookup (if targetPath == null and pathMap == null)
        if (pathMap == null && targetPath == null) {
            String relPath = relativize(editedRoot, p).replace('\\', '/');
            for (Map.Entry<String, LinkedHashMap<String, EntryRef>> de : allDirs.entrySet()) {
                String dp = de.getKey();
                for (Map.Entry<String, EntryRef> fe : de.getValue().entrySet()) {
                    String name = fe.getKey();
                    String fullPath = joinPath(dp, name).replace('\\', '/');
                    if (fullPath.equals(relPath)
                            || fullPath.endsWith("/" + relPath)
                            || relPath.endsWith("/" + name)) {
                        edits.put(fullPath, new EditSlot(p, dp, false, fe.getValue().entry));
                        return;
                    }
                }
            }
        }

        // 2) Basename match with size, then basename alone.
        List<EntryRef> cands = pakNameMap.get(fl);
        String tp = pathMap != null ? pathMap.get(p.getName()) : targetPath;
        if (cands != null && !cands.isEmpty()) {
            if (tp != null) {
                List<EntryRef> filtered = new ArrayList<>();
                for (EntryRef r : cands) {
                    if (r.fullPath.contains(tp)) filtered.add(r);
                }
                if (!filtered.isEmpty()) {
                    long sz = p.length();
                    EntryRef pick = null;
                    for (EntryRef r : filtered) {
                        if (r.entry.uncompressedSize() == sz) { pick = r; break; }
                    }
                    if (pick == null) pick = filtered.get(0);
                    edits.put(pick.fullPath, new EditSlot(p, tp, false, pick.entry));
                    return;
                }
            }
            long sz = p.length();
            EntryRef pick = null;
            for (EntryRef r : cands) {
                if (r.entry.uncompressedSize() == sz) { pick = r; break; }
            }
            if (pick == null) pick = cands.get(0);

            if (tp != null && forceAdd) {
                String newFp = trimSlash(tp) + "/" + p.getName();
                edits.put(newFp, new EditSlot(p, tp, true, pick.entry));
            } else {
                edits.put(pick.fullPath, new EditSlot(p, pick.dirPath, false, pick.entry));
            }
            return;
        }

        // 3) Stem+ext match.
        String stem = stripExt(fl);
        String ext = extLower(p.getName());
        for (Map.Entry<String, LinkedHashMap<String, EntryRef>> de : allDirs.entrySet()) {
            String dp = de.getKey();
            for (Map.Entry<String, EntryRef> fe : de.getValue().entrySet()) {
                String name = fe.getKey();
                if (stripExt(name.toLowerCase(Locale.ROOT)).equals(stem)
                        && extLower(name).equals(ext)) {
                    String fullPath = joinPath(dp, name).replace('\\', '/');
                    if (tp != null && forceAdd) {
                        edits.put(trimSlash(tp) + "/" + p.getName(),
                                new EditSlot(p, tp, true, fe.getValue().entry));
                    } else {
                        edits.put(fullPath, new EditSlot(p, dp, false, fe.getValue().entry));
                    }
                    return;
                }
            }
        }

        // 4) forceAdd → create brand-new entry using a template.
        if (forceAdd) {
            TencentPakEntry template = null;
            for (Map.Entry<String, LinkedHashMap<String, EntryRef>> de : allDirs.entrySet()) {
                for (Map.Entry<String, EntryRef> fe : de.getValue().entrySet()) {
                    if (extLower(fe.getKey()).equals(ext)) { template = fe.getValue().entry; break; }
                }
                if (template != null) break;
            }
            if (template == null) {
                for (Map.Entry<String, LinkedHashMap<String, EntryRef>> de : allDirs.entrySet()) {
                    for (Map.Entry<String, EntryRef> fe : de.getValue().entrySet()) {
                        template = fe.getValue().entry;
                        break;
                    }
                    if (template != null) break;
                }
            }
            if (template == null) return; // nothing to imitate

            String rel = relativize(editedRoot, p).replace('\\', '/');
            String dirKey = tp != null ? tp : dirOf(rel);
            String fp = (dirKey == null || dirKey.isEmpty())
                    ? p.getName()
                    : trimSlash(dirKey) + "/" + p.getName();
            EditSlot es = new EditSlot(p, dirKey, true, template);
            es.template = template;
            edits.put(fp, es);
        }
    }

    private static void writeEditedEntry(PakWriter w, RandomAccessFile srcRaf,
                                         TencentPakEntry ne, File newFile,
                                         String fullPath,
                                         TencentPakEntry old,
                                         Object zstdDict) throws IOException {
        byte[] raw = readAll(newFile);
        String pakRel = fullPath;
        int cm = old.compressionMethod();
        int em = old.encryptionMethod();
        boolean encrypted = old.encrypted();

        ne.setUncompressedSize(raw.length);
        ne.setCompressionMethod(cm);
        ne.setEncryptionMethod(em);
        ne.setEncrypted(encrypted);
        ne.setUnk1(old.unk1());
        ne.setIndexNewSep(old.indexNewSep());
        // unk2 preserved for edits of existing entries.
        ne.setUnk2(old.unk2());

        if (cm == PakConstants.CM_NONE) {
            byte[] stored = encrypted
                    ? PakEncryptor.encryptContent(raw, pakRel, em)
                    : raw;
            ne.setOffset(w.position());
            ne.setSize(raw.length);
            w.writeBytes(stored);
        } else {
            int cs = old.compressionBlockSize() > 0 ? old.compressionBlockSize() : 0x10000;
            List<byte[]> chunks = chunk(raw, cs);
            int[] order = PakCrypto.generateBlockIndices(chunks.size(), em);
            List<byte[]> cipherByLogical = new ArrayList<>(chunks.size());
            for (byte[] chunk : chunks) {
                byte[] compressed = compress(chunk, cm, zstdDict);
                byte[] cipher = encrypted
                        ? PakEncryptor.encryptContent(compressed, pakRel, em)
                        : compressed;
                cipherByLogical.add(cipher);
            }
            int[] inv = new int[chunks.size()];
            for (int i = 0; i < order.length; i++) inv[order[i]] = i;

            List<PakCompressedBlock> newBlks = new ArrayList<>(chunks.size());
            for (int phys = 0; phys < chunks.size(); phys++) {
                long s = w.position();
                w.writeBytes(cipherByLogical.get(inv[phys]));
                long e = w.position();
                newBlks.add(new PakCompressedBlock(s, e));
            }
            ne.setCompressedBlocks(newBlks);
            ne.setOffset(newBlks.isEmpty() ? w.position() : newBlks.get(0).start);
            long total = 0;
            for (PakCompressedBlock b : newBlks) total += (b.end - b.start);
            ne.setSize(total);
        }

        // Recompute SHA1 over stored region for the entry's content_hash.
        byte[] stored = w.readBack(ne.offset(), (int) Math.min(ne.size(), Integer.MAX_VALUE));
        ne.setContentHash(sha1(stored));
    }

    private static void writeNewEntry(PakWriter w, TencentPakEntry ne,
                                      File newFile, String fp,
                                      String mountPoint, Object zstdDict)
            throws IOException {
        byte[] raw = readAll(newFile);
        String pakRel = fp;

        ne.setUncompressedSize(raw.length);
        // unk2 = SHA1(mount_point + full_path, lowercased)
        String fullStr = (mountPoint == null ? "" : mountPoint) + fp;
        ne.setUnk2(sha1(fullStr.toLowerCase(Locale.ROOT)
                .getBytes(StandardCharsets.UTF_8)));

        int cm = ne.compressionMethod();
        int em = ne.encryptionMethod();
        boolean encrypted = ne.encrypted();

        if (cm == PakConstants.CM_NONE) {
            byte[] stored = encrypted
                    ? PakEncryptor.encryptContent(raw, pakRel, em) : raw;
            ne.setOffset(w.position());
            ne.setSize(raw.length);
            w.writeBytes(stored);
        } else {
            int cs = ne.compressionBlockSize() > 0 ? ne.compressionBlockSize() : 0x10000;
            List<byte[]> chunks = chunk(raw, cs);
            int[] order = PakCrypto.generateBlockIndices(chunks.size(), em);
            List<byte[]> cipherByLogical = new ArrayList<>(chunks.size());
            for (byte[] chunk : chunks) {
                byte[] compressed = compress(chunk, cm, zstdDict);
                byte[] cipher = encrypted
                        ? PakEncryptor.encryptContent(compressed, pakRel, em) : compressed;
                cipherByLogical.add(cipher);
            }
            int[] inv = new int[chunks.size()];
            for (int i = 0; i < order.length; i++) inv[order[i]] = i;

            List<PakCompressedBlock> newBlks = new ArrayList<>(chunks.size());
            for (int phys = 0; phys < chunks.size(); phys++) {
                long s = w.position();
                w.writeBytes(cipherByLogical.get(inv[phys]));
                long e = w.position();
                newBlks.add(new PakCompressedBlock(s, e));
            }
            ne.setCompressedBlocks(newBlks);
            ne.setOffset(newBlks.isEmpty() ? w.position() : newBlks.get(0).start);
            long total = 0;
            for (PakCompressedBlock b : newBlks) total += (b.end - b.start);
            ne.setSize(total);
        }

        byte[] stored = w.readBack(ne.offset(), (int) Math.min(ne.size(), Integer.MAX_VALUE));
        ne.setContentHash(sha1(stored));
    }

    private static void copyEntry(PakWriter w, RandomAccessFile srcRaf,
                                  TencentPakEntry ne, TencentPakEntry old) throws IOException {
        ne.setUncompressedSize(old.uncompressedSize());
        ne.setCompressionMethod(old.compressionMethod());
        ne.setEncryptionMethod(old.encryptionMethod());
        ne.setEncrypted(old.encrypted());
        ne.setUnk1(old.unk1());
        ne.setUnk2(old.unk2());
        ne.setIndexNewSep(old.indexNewSep());
        ne.setCompressionBlockSize(old.compressionBlockSize());
        ne.setContentHash(old.contentHash());

        if (old.compressionMethod() == PakConstants.CM_NONE) {
            long readLen = old.size();
            if (old.encrypted()) {
                readLen = PakCrypto.alignEncryptedContentSize(readLen, old.encryptionMethod());
            }
            long start = w.position();
            w.copyFromSource(old.offset(), readLen);
            ne.setOffset(start);
            ne.setSize(old.size());
        } else if (old.compressedBlocks() != null && !old.compressedBlocks().isEmpty()) {
            List<PakCompressedBlock> newBlocks = new ArrayList<>();
            for (PakCompressedBlock ob : old.compressedBlocks()) {
                long unc = ob.end - ob.start;
                long enc = old.encrypted()
                        ? PakCrypto.alignEncryptedContentSize(unc, old.encryptionMethod())
                        : unc;
                long start = w.position();
                w.copyFromSource(ob.start, enc);
                long end = w.position();
                newBlocks.add(new PakCompressedBlock(start, end));
            }
            ne.setCompressedBlocks(newBlocks);
            ne.setOffset(newBlocks.isEmpty() ? w.position() : newBlocks.get(0).start);
        } else {
            // No blocks and not compressed; copy zero bytes.
            ne.setOffset(w.position());
            ne.setSize(0);
        }
    }

    // ---------------------------------------------------------------
    // Compression helper
    // ---------------------------------------------------------------
    private static byte[] compress(byte[] chunk, int cm, Object zstdDict) {
        if (cm == PakConstants.CM_ZLIB) {
            java.util.zip.Deflater def = new java.util.zip.Deflater(9);
            def.setInput(chunk);
            def.finish();
            java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            while (!def.finished()) {
                int n = def.deflate(buf);
                baos.write(buf, 0, n);
            }
            def.end();
            return baos.toByteArray();
        }
        if (cm == PakConstants.CM_ZSTD || cm == PakConstants.CM_ZSTD_DICT) {
            int[] levels = {22, 19, 16, 13, 10, 7, 4, 1};
            for (int lvl : levels) {
                try {
                    long bound = Zstd.compressBound(chunk.length);
                    byte[] out = new byte[(int) bound];
                    long written = Zstd.compress(out, chunk, lvl);
                    if (Zstd.isError(written)) continue;
                    byte[] trimmed = new byte[(int) written];
                    System.arraycopy(out, 0, trimmed, 0, (int) written);
                    return trimmed;
                } catch (Throwable ignored) {
                }
            }
        }
        return chunk;
    }

    // ---------------------------------------------------------------
    // Small helpers
    // ---------------------------------------------------------------
    private static int countTotalEntries(LinkedHashMap<String, LinkedHashMap<String, EntryRef>> dirs) {
        int n = 0;
        for (LinkedHashMap<String, EntryRef> d : dirs.values()) n += d.size();
        return n;
    }

    private static List<File> listFilesRecursive(File root) {
        List<File> out = new ArrayList<>();
        File[] children = root.listFiles();
        if (children == null) return out;
        for (File c : children) {
            if (c.isFile()) out.add(c);
            else if (c.isDirectory()) out.addAll(listFilesRecursive(c));
        }
        return out;
    }

    private static List<byte[]> chunk(byte[] src, int cs) {
        List<byte[]> out = new ArrayList<>();
        for (int i = 0; i < src.length; i += cs) {
            int end = Math.min(i + cs, src.length);
            byte[] c = new byte[end - i];
            System.arraycopy(src, i, c, 0, c.length);
            out.add(c);
        }
        if (out.isEmpty()) out.add(new byte[0]);
        return out;
    }

    private static byte[] readAll(File f) throws IOException {
        try (java.io.FileInputStream in = new java.io.FileInputStream(f)) {
            java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream(
                    (int) Math.min(f.length(), Integer.MAX_VALUE));
            byte[] buf = new byte[64 * 1024];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            return out.toByteArray();
        }
    }

    private static byte[] sha1(byte[] data) {
        try {
            return MessageDigest.getInstance("SHA-1").digest(data);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private static String relativize(File root, File p) {
        String r = root.getAbsolutePath();
        String a = p.getAbsolutePath();
        if (a.startsWith(r)) {
            String rel = a.substring(r.length());
            while (rel.startsWith("/") || rel.startsWith("\\")) rel = rel.substring(1);
            return rel;
        }
        return p.getName();
    }

    private static String joinPath(String dir, String name) {
        if (dir == null || dir.isEmpty() || ".".equals(dir)) return name;
        return dir + "/" + name;
    }

    private static String stripExt(String name) {
        int i = name.lastIndexOf('.');
        return i < 0 ? name : name.substring(0, i);
    }

    private static String extLower(String name) {
        int i = name.lastIndexOf('.');
        return i < 0 ? "" : name.substring(i).toLowerCase(Locale.ROOT);
    }

    private static String trimSlash(String s) {
        if (s == null) return "";
        while (s.endsWith("/")) s = s.substring(0, s.length() - 1);
        return s;
    }

    private static String dirOf(String relPath) {
        int i = relPath.lastIndexOf('/');
        if (i < 0) return "";
        return relPath.substring(0, i + 1);
    }

    private static String normalizeDir(String tp,
                                       LinkedHashMap<String, LinkedHashMap<String, EntryRef>> dirs) {
        if (tp == null) return null;
        String t = tp.replace('\\', '/').trim();
        for (String existing : dirs.keySet()) {
            if (existing.strip().equalsIgnoreCase(t.strip())) {
                return existing;
            }
        }
        return trimSlash(t) + "/";
    }

    private static TencentPakEntry copyOf(TencentPakEntry e) {
        return e.copy();
    }

    // ---------------------------------------------------------------
    // Small data classes
    // ---------------------------------------------------------------
    static final class EntryRef {
        final String fullPath;
        final int slot;
        final TencentPakEntry entry;
        EntryRef(String fp, int s, TencentPakEntry e) {
            this.fullPath = fp; this.slot = s; this.entry = e;
        }
        /** Convenience for name-only slots in normalized dirs. */
        EntryRef(String fullPath, int slot) {
            this(fullPath, slot, null);
        }
    }

    static final class EditSlot {
        final File file;
        final String dirKey;
        final boolean isNew;
        final TencentPakEntry baseEntry;
        TencentPakEntry template;
        EditSlot(File f, String dk, boolean isNew, TencentPakEntry base) {
            this.file = f; this.dirKey = dk; this.isNew = isNew; this.baseEntry = base;
            this.template = base;
        }
    }

    static final class NewEntry {
        final String dirKey;
        final String name;
        final TencentPakEntry entry;
        int slot = -1;
        NewEntry(String dk, String n, TencentPakEntry e) {
            this.dirKey = dk; this.name = n; this.entry = e;
        }
    }

    public static final class DirectoryListing {
        private final String mountPoint;
        private final LinkedHashMap<String, LinkedHashMap<String, EntryRef>> dirs;
        private final List<TencentPakEntry> entries;
        public DirectoryListing(String mp,
                                LinkedHashMap<String, LinkedHashMap<String, EntryRef>> dirs,
                                List<TencentPakEntry> entries) {
            this.mountPoint = mp; this.dirs = dirs; this.entries = entries;
        }
        public String mountPoint() { return mountPoint; }
        public LinkedHashMap<String, LinkedHashMap<String, EntryRef>> dirs() { return dirs; }
        public List<TencentPakEntry> entries() { return entries; }
    }
}