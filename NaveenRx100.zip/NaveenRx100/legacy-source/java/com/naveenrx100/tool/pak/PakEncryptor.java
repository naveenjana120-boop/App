/*
 * NaveenRx100 Tool - PakEncryptor
 *
 * EDUCATIONAL PURPOSE ONLY
 * This code demonstrates binary file format analysis,
 * archive writing, and cryptography for learning purposes.
 *
 * Not intended for illegal modification of any software.
 *
 * Developer: NaveenRx100
 * Credit: @NaveenRx100
 */
package com.naveenrx100.tool.pak;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/**
 * Write-side encryption symmetric to {@link PakCrypto}'s decrypt methods.
 *
 * <ul>
 *   <li>{@link #encryptContent(byte[], String, int)} — symmetric to
 *       {@code PakCrypto.decrypt_block}, used for file content.</li>
 *   <li>{@link #encryptIndex(byte[], TencentPakInfo)} — symmetric to
 *       {@code PakCrypto.decrypt_index}, used for the index.</li>
 * </ul>
 */
public final class PakEncryptor {

    private PakEncryptor() {}

    // ================================================================
    // CONTENT ENCRYPTION  (matches HXE.py _encrypt_plaintext)
    // ================================================================
    /**
     * @param plaintext raw bytes to encrypt (length already aligned by caller
     *                  if required by method)
     * @param pakRelPath relative path inside the PAK, used for SM4 key derivation
     * @param method     encryption method id
     */
    public static byte[] encryptContent(byte[] plaintext,
                                        String pakRelPath,
                                        int method) throws IOException {
        if (PakCrypto.isSimple1Method(method)) {
            byte[] out = new byte[plaintext.length];
            for (int i = 0; i < plaintext.length; i++) {
                out[i] = (byte) (plaintext[i] ^ PakConstants.SIMPLE1_DECRYPT_KEY);
            }
            return out;
        }
        if (PakCrypto.isSimple2Method(method)) {
            return encryptSimple2(plaintext);
        }
        if (PakCrypto.isSm4Method(method)) {
            return encryptSm4(plaintext, pakRelPath, method);
        }
        return plaintext;
    }

    // ---------------------------------------------------------------
    // SIMPLE2: rolling XOR keyed on the 4-byte little-endian SIMPLE2 key
    // ---------------------------------------------------------------
    private static byte[] encryptSimple2(byte[] plaintext) throws IOException {
        int blockSize = PakConstants.SIMPLE2_BLOCK_SIZE;
        int pad = (-plaintext.length % blockSize + blockSize) % blockSize;
        byte[] padded = new byte[plaintext.length + pad];
        System.arraycopy(plaintext, 0, padded, 0, plaintext.length);

        int key;
        byte[] keyBytes = PakConstants.SIMPLE2_DECRYPT_KEY;
        key = (keyBytes[0] & 0xFF)
                | ((keyBytes[1] & 0xFF) << 8)
                | ((keyBytes[2] & 0xFF) << 16)
                | ((keyBytes[3] & 0xFF) << 24);

        ByteBuffer in = ByteBuffer.wrap(padded).order(ByteOrder.LITTLE_ENDIAN);
        ByteBuffer out = ByteBuffer.allocate(padded.length).order(ByteOrder.LITTLE_ENDIAN);
        int rolling = key;
        for (int i = 0; i < padded.length; i += 4) {
            int x = in.getInt();
            int c = rolling ^ x;
            out.putInt(c);
            rolling ^= c;
        }
        return out.array();
    }

    // ---------------------------------------------------------------
    // SM4: pad to 16-byte boundary with zeros, encrypt per 16-byte block
    // ---------------------------------------------------------------
    private static byte[] encryptSm4(byte[] plaintext, String pakRelPath, int method)
            throws IOException {
        byte[] key = PakCrypto.deriveSm4Key(pakRelPath, method);
        SM4Cipher sm4 = new SM4Cipher(key);

        int blockSize = 16;
        int pad = (-plaintext.length % blockSize + blockSize) % blockSize;
        byte[] padded = new byte[plaintext.length + pad];
        System.arraycopy(plaintext, 0, padded, 0, plaintext.length);

        ByteArrayOutputStream out = new ByteArrayOutputStream(padded.length);
        byte[] block = new byte[16];
        for (int i = 0; i < padded.length; i += 16) {
            System.arraycopy(padded, i, block, 0, 16);
            byte[] enc = sm4.encrypt(block);
            out.write(enc, 0, 16);
        }
        return out.toByteArray();
    }

    // ================================================================
    // INDEX ENCRYPTION  (matches HXE.py inject_files() tail)
    // ================================================================
    public static byte[] encryptIndex(byte[] plainIndex,
                                      TencentPakInfo info) throws IOException {
        int version = info.version();
        boolean enc = info.indexEncrypted();

        if (!enc) return plainIndex;

        if (version > 7) {
            // Try AES-CBC with RSA-extracted key/iv.
            try {
                byte[] key = PakCrypto.rsaExtract(info.packedKey(), PakConstants.RSA_MOD_1);
                byte[] iv = PakCrypto.rsaExtract(info.packedIv(), PakConstants.RSA_MOD_1);
                if (key != null && key.length == 32 && iv != null && iv.length >= 16) {
                    return aesCbcPkcs7Encrypt(plainIndex, key, slice(iv, 0, 16));
                }
            } catch (Exception e) {
                // fall through to SIMPLE1
            }
            // Fallback in HXE.py: SIMPLE1 with keystream bytes (defensive).
            return simple1IndexEncrypt(plainIndex);
        } else {
            return simple1IndexEncrypt(plainIndex);
        }
    }

    private static byte[] simple1IndexEncrypt(byte[] plain) {
        byte[] out = new byte[plain.length];
        for (int i = 0; i < plain.length; i++) {
            out[i] = (byte) (plain[i] ^ PakConstants.SIMPLE1_DECRYPT_KEY);
        }
        return out;
    }

    private static byte[] aesCbcPkcs7Encrypt(byte[] plain, byte[] key32, byte[] iv16)
            throws Exception {
        // PKCS7 pad
        int blockSize = 16;
        int pad = blockSize - (plain.length % blockSize);
        if (pad == 0) pad = blockSize;
        byte[] padded = new byte[plain.length + pad];
        System.arraycopy(plain, 0, padded, 0, plain.length);
        for (int i = 0; i < pad; i++) {
            padded[plain.length + i] = (byte) pad;
        }

        Cipher cipher = Cipher.getInstance("AES/CBC/NoPadding");
        // HXE.py: AES.new(key, MODE_CBC, iv[:16]) with 32-byte key → AES-256
        cipher.init(Cipher.ENCRYPT_MODE,
                new SecretKeySpec(key32, "AES"),
                new IvParameterSpec(iv16));
        return cipher.doFinal(padded);
    }

    private static byte[] slice(byte[] arr, int off, int len) {
        byte[] out = new byte[len];
        System.arraycopy(arr, off, out, 0, len);
        return out;
    }

    /**
     * Utility for callers that need the same SHA1 that goes into
     * the footer's encrypted_index_hash field.
     */
    public static byte[] sha1(byte[] data) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-1");
            return md.digest(data);
        } catch (Exception e) {
            throw new RuntimeException("SHA-1 unavailable", e);
        }
    }

    /**
     * Derives the SM4 key exactly as HXE.py's _derive_sm4_key does:
     * SHA1(stem_lowercased + secret)[:16].
     */
    public static byte[] deriveSm4KeyForTest(String stemLower, int method) {
        String secret;
        if (method == PakConstants.EM_SM4_2) {
            secret = PakConstants.SM4_SECRET_2;
        } else if (method == PakConstants.EM_SM4_4) {
            secret = PakConstants.SM4_SECRET_4;
        } else {
            int idx = (method - PakConstants.EM_SM4_NEW_BASE)
                    % PakConstants.SM4_SECRET_NEW.length;
            secret = PakConstants.SM4_SECRET_NEW[idx] + method;
        }
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-1");
            byte[] full = md.digest((stemLower + secret).getBytes(StandardCharsets.UTF_8));
            byte[] key = new byte[16];
            System.arraycopy(full, 0, key, 0, 16);
            return key;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}