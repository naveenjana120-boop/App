/*
 * NaveenRx100 Tool - PakRepackSelfTest
 *
 * EDUCATIONAL PURPOSE ONLY
 * This code demonstrates binary file format analysis,
 * archive writing, and cryptography for learning purposes.
 *
 * Not intended for illegal modification of any software.
 *
 * Developer: NaveenRx100
 * Credit: @NaveenRx100
 */
package com.naveenrx100.tool.pak;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Self-tests using synthetic data.
 *
 * <p>Documented limitations: real PAKs use version 11/12 features we cannot
 * fully fabricate here without a genuine sample. The synthetic PAK we build
 * exercises version 4-6 fields (no AES-packed key, no zstd dict). This is
 * sufficient for verifying the write/read round-trip for those fields.</p>
 */
public final class PakRepackSelfTest {

    private PakRepackSelfTest() {}

    public static String run(File workDir) {
        StringBuilder sb = new StringBuilder();
        try {
            // 1. Build a synthetic PAK in-memory using our writer stack.
            File tiny = new File(workDir, "tiny_synthetic.pak");
            buildSyntheticPak(tiny);
            sb.append("[OK] Synthetic PAK built: ").append(tiny.length()).append(" bytes\n");

            // 2. Read it back — verify entry count and stored content.
            try (TencentPakFile pak = TencentPakFile.open(tiny)) {
                int n = pak.allEntriesInOrder().size();
                sb.append("[OK] Read back ").append(n).append(" entries\n");
                if (n != 1) throw new AssertionError("expected 1 entry, got " + n);
            }

            // 3. Inject a new file via PakInjector.
            File injectSrc = new File(workDir, "inject_hello.txt");
            writeAll(injectSrc, "HELLO FROM SELF TEST\n".getBytes(StandardCharsets.UTF_8));
            File injectedPak = new File(workDir, "tiny_injected.pak");

            List<PakInjector.InjectItem> plan = new ArrayList<>();
            plan.add(new PakInjector.InjectItem(
                    "Content/Lua/test/hello.txt",
                    injectSrc,
                    PakConstants.CM_NONE,
                    0,
                    false,
                    0,
                    0));
            try (TencentPakFile src = TencentPakFile.open(tiny)) {
                PakInjector.inject(src, plan, injectedPak, false, null);
            }
            sb.append("[OK] Injected file → ").append(injectedPak.length()).append(" bytes\n");

            // 4. Verify injected PAK reads back with 2 entries.
            try (TencentPakFile inj = TencentPakFile.open(injectedPak)) {
                int n = inj.allEntriesInOrder().size();
                sb.append("[OK] Injected PAK has ").append(n).append(" entries\n");
                if (n != 2) throw new AssertionError("expected 2 entries, got " + n);
            }

            // 5. Build a NEW PAK from a template.
            File editRoot = new File(workDir, "edit_root");
            //noinspection ResultOfMethodCallIgnored
            editRoot.mkdirs();
            File edit1 = new File(editRoot, "mytest.lua");
            writeAll(edit1, "return 42\n".getBytes(StandardCharsets.UTF_8));

            File newPak = new File(workDir, "tiny_new.pak");
            try (TencentPakFile template = TencentPakFile.open(tiny)) {
                // We pass template as File directly since PakBuilder opens it.
            }
            PakBuilder.build(tiny, editRoot, newPak, "Content/Test/", null, null);
            sb.append("[OK] Built new PAK: ").append(newPak.length()).append(" bytes\n");

            try (TencentPakFile built = TencentPakFile.open(newPak)) {
                int n = built.allEntriesInOrder().size();
                sb.append("[OK] New PAK has ").append(n).append(" entries\n");
                if (n != 1) throw new AssertionError("expected 1 entry, got " + n);
            }

            sb.append("[PASS] All self-tests completed.\n");
            sb.append("LIMITATIONS:\n");
            sb.append("  - Synthetic PAK only uses uncompressed, unencrypted entries.\n");
            sb.append("  - Version 5-6 fields tested; versions 7-12 (AES + packed key)\n");
            sb.append("    require a genuine sample and remain untested by self-test.\n");
            sb.append("  - Zstd with dictionary is not exercised.\n");
            sb.append("  - unk2 hashing path is exercised on inject.\n");

        } catch (Throwable t) {
            sb.append("[FAIL] ").append(t.getClass().getSimpleName())
              .append(": ").append(t.getMessage()).append('\n');
            StackTraceElement[] st = t.getStackTrace();
            for (int i = 0; i < Math.min(6, st.length); i++) {
                sb.append("   at ").append(st[i]).append('\n');
            }
        }
        return sb.toString();
    }

    // ---------------------------------------------------------------
    // Build a minimal v5, unencrypted, uncompressed PAK with one file.
    // ---------------------------------------------------------------
    private static void buildSyntheticPak(File out) throws IOException {
        // Content: "hello world\n"
        byte[] content = "hello world\n".getBytes(StandardCharsets.UTF_8);
        long contentOffset = 0;

        // Entry: hash=SHA1(content), offset=0, uncompressed=len, cm=0, size=len,
        //        unk1=0, unk2=20 zeros
        TencentPakEntry entry = new TencentPakEntry();
        entry.setContentHash(sha1(content));
        entry.setOffset(0);
        entry.setUncompressedSize(content.length);
        entry.setCompressionMethod(PakConstants.CM_NONE);
        entry.setSize(content.length);
        entry.setUnk1(0);
        entry.setUnk2(new byte[20]);
        entry.setCompressionBlockSize(0);
        entry.setEncrypted(false);
        entry.setEncryptionMethod(0);
        entry.setIndexNewSep(0);
        entry.setCompressedBlocks(new ArrayList<>());

        List<TencentPakEntry> entries = new ArrayList<>();
        entries.add(entry);

        LinkedHashMap<String, LinkedHashMap<String, Integer>> dirTable = new LinkedHashMap<>();
        LinkedHashMap<String, Integer> inner = new LinkedHashMap<>();
        inner.put("hello.txt", 0);
        dirTable.put("Content/", inner);

        int version = 5;
        byte[] indexPlain = PakIndexWriter.serialize("", entries, dirTable, version);
        byte[] indexSha1 = sha1(indexPlain);

        // Write: [content][index][footer (v5: no magic encryption)]
        // Footer layout (fixed tail): flag(1) magic(4) version(4) hash(20) size(8) offset(8)
        try (RandomAccessFile raf = new RandomAccessFile(out, "rw")) {
            raf.setLength(0);
            raf.write(content);
            long idxOff = content.length;
            raf.write(indexPlain); // unencrypted index for synthetic PAK
            // Flag byte (index_encrypted = 0)
            raf.write(0);
            // magic
            raf.write(new byte[]{'P', 'A', 'K', 0});
            // version
            writeLe32(raf, version);
            // index hash
            raf.write(indexSha1);
            // index size
            writeLe64(raf, indexPlain.length);
            // index offset
            writeLe64(raf, idxOff);
        }
    }

    private static byte[] sha1(byte[] d) {
        try { return MessageDigest.getInstance("SHA-1").digest(d); }
        catch (Exception e) { throw new RuntimeException(e); }
    }
    private static void writeLe32(RandomAccessFile raf, long v) throws IOException {
        for (int i = 0; i < 4; i++) raf.write((int) ((v >>> (8 * i)) & 0xFF));
    }
    private static void writeLe64(RandomAccessFile raf, long v) throws IOException {
        for (int i = 0; i < 8; i++) raf.write((int) ((v >>> (8 * i)) & 0xFF));
    }
    private static void writeAll(File f, byte[] data) throws IOException {
        try (java.io.FileOutputStream o = new java.io.FileOutputStream(f)) {
            o.write(data);
        }
    }
    // Silence unused import warnings
    static { ByteBuffer bb = ByteBuffer.allocate(0).order(ByteOrder.LITTLE_ENDIAN); }
    @SuppressWarnings("unused")
    private static void unused(Map<?, ?> m) {}
}