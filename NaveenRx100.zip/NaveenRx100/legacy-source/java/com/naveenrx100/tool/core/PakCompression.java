/*
 * NaveenRx100 Tool - Educational Module
 * EDUCATIONAL PURPOSE ONLY.
 * This code demonstrates Android development, local file handling, binary formats,
 * and cryptography for learning with files you own or are authorized to inspect.
 * Not intended for illegal modification of any software.
 * Developer: NaveenRx100 | Credit: @NaveenRx100
 */
package com.naveenrx100.tool.core;

import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.Map;

/** HXE.py PakCompression port, including bounded dictionary/decompressor caching. */
public final class PakCompression {
    public static final int CM_NONE=0, CM_ZLIB=1, CM_ZSTD=6, CM_ZSTD_DICT=8;
    /** zstandard.DICT_TYPE_AUTO compatibility value: let zstd-jni identify the dictionary format. */
    public static final int DICT_TYPE_AUTO=0;
    private static final int CACHE_LIMIT=33;
    private static final Map<String,ZSTDDecompressor> CACHE = new LinkedHashMap<String,ZSTDDecompressor>(CACHE_LIMIT,0.75f,true) {
        @Override protected boolean removeEldestEntry(Map.Entry<String,ZSTDDecompressor> e) { return size()>CACHE_LIMIT; }
    };
    private PakCompression() {}
    public static byte[] zstdDictionary(byte[] data) { if(data==null) throw new IllegalArgumentException("dictionary data is null"); return data.clone(); }
    public static byte[] zstd_dictionary(byte[] data) { return zstdDictionary(data); }
    public static byte[] zstdDictionary(byte[] data, int dictType) { if(dictType!=DICT_TYPE_AUTO) throw new IllegalArgumentException("Only DICT_TYPE_AUTO is supported"); return zstdDictionary(data); }
    private static String key(byte[] dict) { if(dict==null) return "<none>"; byte[] h=SHA1Hasher.hash(dict); StringBuilder b=new StringBuilder(h.length*2); for(byte x:h)b.append(String.format(java.util.Locale.ROOT,"%02x",x&255)); return b.toString(); }
    private static ZSTDDecompressor get(byte[] dict) { synchronized(CACHE) { String k=key(dict); ZSTDDecompressor d=CACHE.get(k); if(d==null){d=new ZSTDDecompressor(dict);CACHE.put(k,d);}return d; } }
    public static byte[] decompressBlock(byte[] block, byte[] dict, int method) {
        if(block==null) return new byte[0];
        if(method==CM_ZLIB) return ZLIBDecompressor.decompressBlock(block);
        if(method==CM_ZSTD || method==CM_ZSTD_DICT) {
            byte[] selected=method==CM_ZSTD_DICT?dict:null;
            try { return get(selected).decompressBlock(block, selected, method); } catch(Throwable ignored) { return block.clone(); }
        }
        return block.clone();
    }
    public static byte[] decompress_block(byte[] block, byte[] dict, int method) { return decompressBlock(block,dict,method); }
    public static void clearCache() { synchronized(CACHE){CACHE.clear();} }
}
