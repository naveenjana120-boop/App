/*
 * NaveenRx100 Tool - Educational Module
 * EDUCATIONAL PURPOSE ONLY.
 * This code demonstrates Android development, local file handling, binary formats,
 * and cryptography for learning with files you own or are authorized to inspect.
 * Not intended for illegal modification of any software.
 * Developer: NaveenRx100 | Credit: @NaveenRx100
 */
package com.naveenrx100.tool.core;

import java.util.Arrays;

/** Opcode tables copied from HXE.py: 47 explicit BGMI mappings padded to 64. */
public final class BGMIFormat {
    private BGMIFormat() {}
    public static final int[] BGMI_TO_STD = {
        13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,
        0,1,2,3,4,5,6,7,8,9,10,11,12,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,
        47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63
    };
    public static final int[] STD_TO_BGMI = buildReverse();
    public static final int[] STD_FMT = {
        0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,0,0,0,0,0,0,0,0,2,2,0,2,0,1,0,3
    };
    public static final int iABC=0, iABx=1, iAsBx=2, iAx=3;
    private static int[] buildReverse() {
        int[] reverse = new int[64]; Arrays.fill(reverse, -1);
        for (int bgmi=0; bgmi<BGMI_TO_STD.length; bgmi++) {
            int standard=BGMI_TO_STD[bgmi];
            if (standard>=0 && standard<reverse.length) reverse[standard]=bgmi;
        }
        return reverse;
    }
    public static int toStandard(int opcode) { return opcode>=0 && opcode<BGMI_TO_STD.length ? BGMI_TO_STD[opcode] : opcode; }
    public static int toBgmi(int opcode) { return opcode>=0 && opcode<STD_TO_BGMI.length && STD_TO_BGMI[opcode]>=0 ? STD_TO_BGMI[opcode] : opcode; }
    public static int formatForStandardOpcode(int opcode) { return opcode>=0 && opcode<STD_FMT.length ? STD_FMT[opcode] : iABC; }
}
