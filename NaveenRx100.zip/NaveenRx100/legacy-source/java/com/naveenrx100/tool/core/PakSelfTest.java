/*
 * NaveenRx100 Tool - Educational Module
 * EDUCATIONAL PURPOSE ONLY.
 * This code demonstrates Android development, local file handling, binary formats,
 * and cryptography for learning with files you own or are authorized to inspect.
 * Not intended for illegal modification of any software.
 * Developer: NaveenRx100 | Credit: @NaveenRx100
 */
package com.naveenrx100.tool.core;

import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.zip.Deflater;

/** Self-check for footer/index parsing and compression. Creates a temporary synthetic v11 PAK. */
public final class PakSelfTest {
    private PakSelfTest() {}
    public static final class Result { public final boolean passed; public final String report; Result(boolean p,String r){passed=p;report=r;} }
    public static Result run() {
        StringBuilder report=new StringBuilder();
        try {
            byte[] original="Batch5 zlib self test".getBytes(StandardCharsets.UTF_8);Deflater def=new Deflater();def.setInput(original);def.finish();byte[] temp=new byte[1024];int n=def.deflate(temp);def.end();byte[] packed=Arrays.copyOf(temp,n);byte[] inflated=ZLIBDecompressor.decompressBlock(packed);if(!Arrays.equals(original,inflated))throw new AssertionError("ZLIB round-trip failed");report.append("ZLIB: PASS\n");
            byte[] index=makeEmptyV11Index();File f=File.createTempFile("batch5-selftest-", ".pak");try(FileOutputStream out=new FileOutputStream(f)){out.write(index);out.write(makeFooter(index));}
            try(TencentPakFile pak=new TencentPakFile(f,true)){if(pak.getPakInfo().version!=11)throw new AssertionError("Footer version mismatch");if(!"/".equals(pak.getMountPoint())&&!pak.getMountPoint().isEmpty())throw new AssertionError("Mount point mismatch");if(pak.getFiles().size()!=0)throw new AssertionError("Expected empty synthetic PAK");if(!pak.verifyIndexHash())throw new AssertionError("Index SHA-1 check failed");}
            // A synthetic v11 index uses an empty mount point, zero file entries, zero directories.
            if(!f.delete())f.deleteOnExit();report.append("Synthetic PAK footer/index parse: PASS\nIndex SHA-1 verification: PASS\n");
            return new Result(true,report.toString());
        } catch(Throwable e){report.append("FAIL: ").append(e.getClass().getSimpleName()).append(": ").append(e.getMessage());return new Result(false,report.toString());}
    }
    private static byte[] makeEmptyV11Index(){byte[] b=new byte[4+0+4+8];put32(b,0,0);put32(b,4,0);put64(b,8,0);return b;}
    private static byte[] makeFooter(byte[] index)throws Exception {
        int[] ks=PakCrypto.zucKeystream();byte[] footer=new byte[TencentPakInfo.memSize(11)];int p=0;
        byte[] zero32=new byte[32],key=wordsLe(ks,7,8);for(int i=0;i<32;i++)footer[p++]=(byte)(zero32[i]^key[i]);
        p+=768;put32(footer,p,ks[8]);p+=4;put32(footer,p,ks[9]);p+=4;
        footer[p++]=(byte)ks[3];put32(footer,p,0x50414B00L ^ (ks[2]&0xffffffffL));p+=4;put32(footer,p,11);p+=4;
        byte[] hash=MessageDigest.getInstance("SHA-1").digest(index),hashKey=wordsLe(ks,4,5);for(int i=0;i<20;i++)footer[p++]=(byte)(hash[i]^hashKey[i]);
        long size=(index.length)^(((ks[10]&0xffffffffL)<<32)|(ks[11]&0xffffffffL));put64(footer,p,size);p+=8;long off=(((ks[0]&0xffffffffL)<<32)|(ks[1]&0xffffffffL));put64(footer,p,off);
        return footer;
    }
    private static byte[] wordsLe(int[] w,int start,int count){byte[] b=new byte[count*4];for(int i=0;i<count;i++)put32(b,i*4,w[start+i]);return b;}
    private static void put32(byte[] b,int p,long v){for(int i=0;i<4;i++)b[p+i]=(byte)(v >>> (8*i));}
    private static void put64(byte[] b,int p,long v){for(int i=0;i<8;i++)b[p+i]=(byte)(v >>> (8*i));}
}
