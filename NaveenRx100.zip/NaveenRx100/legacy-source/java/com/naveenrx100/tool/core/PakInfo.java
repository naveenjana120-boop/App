/*
 * NaveenRx100 Tool - Educational Module
 * EDUCATIONAL PURPOSE ONLY.
 * This code demonstrates Android development, local file handling, binary formats,
 * and cryptography for learning with files you own or are authorized to inspect.
 * Not intended for illegal modification of any software.
 * Developer: NaveenRx100 | Credit: @NaveenRx100
 */
package com.naveenrx100.tool.core;

import java.util.Arrays;

/** PAK footer base fields as decoded by HXE.py's ZUC-derived XOR masks. */
public class PakInfo implements PakCrypto.PakInfo {
    public final boolean index_encrypted; public final long magic; public final int version; public final byte[] index_hash; public final long index_size,index_offset;
    public PakInfo(byte[] buffer,int[] keystream) {
        if(buffer==null||keystream==null||keystream.length<12)throw new IllegalArgumentException("PAK buffer/keystream invalid");
        if(buffer.length<45)throw new IllegalArgumentException("Corrupted PAK: footer shorter than 45 bytes");
        PakReader r=new PakReader(Arrays.copyOfRange(buffer,buffer.length-45,buffer.length));
        boolean encryptedValue=(((r.u1() ^ keystream[3])&255)==1);
        this.magic=(r.u4() ^ (keystream[2]&0xffffffffL))&0xffffffffL;
        this.version=(int)r.u4();
        this.index_encrypted=this.version<=3?false:encryptedValue;
        this.index_hash=this.version>=6?xor(r.bytes(20),wordsLe(keystream,4,5)):new byte[0];
        this.index_size=r.u8() ^ (((keystream[10]&0xffffffffL)<<32)|(keystream[11]&0xffffffffL));
        this.index_offset=r.u8() ^ (((keystream[0]&0xffffffffL)<<32)|(keystream[1]&0xffffffffL));
        if(version<=3) { /* HXE.py forces index_encrypted false for legacy versions. */ }
    }
    protected static byte[] xor(byte[] a,byte[] b){byte[] o=new byte[a.length];for(int i=0;i<a.length;i++)o[i]=(byte)(a[i]^b[i%b.length]);return o;}
    public static int memSize(int ignored){return 45;} public static int _mem_size(int version){return memSize(version);}
    @Override public int getVersion(){return version;} @Override public byte[] getPackedKey(){return new byte[0];} @Override public byte[] getPackedIv(){return new byte[0];}
    static byte[] wordsLe(int[] words,int start,int count){byte[] out=new byte[count*4];for(int i=0;i<count;i++){int v=words[start+i],p=i*4;out[p]=(byte)v;out[p+1]=(byte)(v>>>8);out[p+2]=(byte)(v>>>16);out[p+3]=(byte)(v>>>24);}return out;}
}
