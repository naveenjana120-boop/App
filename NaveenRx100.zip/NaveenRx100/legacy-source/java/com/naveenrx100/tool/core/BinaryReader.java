/*
 * NaveenRx100 Tool - Educational Module
 * EDUCATIONAL PURPOSE ONLY.
 * This code demonstrates Android development, local file handling, binary formats,
 * and cryptography for learning with files you own or are authorized to inspect.
 * Not intended for illegal modification of any software.
 * Developer: NaveenRx100 | Credit: @NaveenRx100
 */
package com.naveenrx100.tool.core;

import java.io.EOFException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;

/** Little-endian reader matching HXE.py BinaryReader string and integer conventions. */
public final class BinaryReader {
    private final byte[] data;
    private int position;
    private final int sizeT;

    public BinaryReader(byte[] data) { this(data, 4); }

    public BinaryReader(byte[] data, int sizeT) {
        if (data == null) throw new IllegalArgumentException("data must not be null");
        if (sizeT != 4 && sizeT != 8) throw new IllegalArgumentException("sizeT must be 4 or 8");
        this.data = data;
        this.position = 0;
        this.sizeT = sizeT;
    }

    public int position() { return position; }
    public int sizeT() { return sizeT; }
    public int remaining() { return data.length - position; }
    public void position(int newPosition) {
        if (newPosition < 0 || newPosition > data.length) throw new IndexOutOfBoundsException("position out of range");
        position = newPosition;
    }

    private void require(int count) throws EOFException {
        if (count < 0 || position > data.length - count) throw new EOFException("Unexpected end of binary data at offset " + position);
    }

    public int readByte() throws EOFException {
        require(1);
        return data[position++] & 0xFF;
    }

    public int int32() throws EOFException {
        require(4);
        int value = (data[position] & 0xFF)
                | ((data[position + 1] & 0xFF) << 8)
                | ((data[position + 2] & 0xFF) << 16)
                | ((data[position + 3] & 0xFF) << 24);
        position += 4;
        return value;
    }

    /** Returns uint32 in a long so values above 2^31-1 remain positive. */
    public long uint32() throws EOFException {
        return int32() & 0xFFFFFFFFL;
    }

    public long int64() throws EOFException {
        require(8);
        long value = 0L;
        for (int i = 0; i < 8; i++) value |= ((long) data[position + i] & 0xFFL) << (8 * i);
        position += 8;
        return value;
    }

    public double readDouble() throws EOFException {
        long bits = int64();
        return Double.longBitsToDouble(bits);
    }

    public byte[] readBytes(int count) throws EOFException {
        require(count);
        byte[] result = Arrays.copyOfRange(data, position, position + count);
        position += count;
        return result;
    }

    private long readSizeT() throws EOFException {
        if (sizeT == 8) {
            long value = int64();
            if (value < 0) throw new IllegalArgumentException("8-byte size_t exceeds Java's supported signed range");
            return value;
        }
        return uint32();
    }

    private int checkedLength(long length) {
        if (length < 0 || length > Integer.MAX_VALUE) throw new IllegalArgumentException("String length is too large: " + length);
        return (int) length;
    }

    /** HXE.py pubg_string(): length byte, 0xFF + uint32 extended length, NUL-inclusive size, XOR payload. */
    public String pubg_string() throws EOFException {
        long size = readByte();
        if (size == 0xFFL) size = uint32();
        if (size == 0L) return null;
        int payloadLength = checkedLength(size - 1L);
        byte[] encoded = readBytes(payloadLength);
        byte[] key = Constants.STRING_XOR_KEY;
        for (int i = 0; i < encoded.length; i++) encoded[i] = (byte) (encoded[i] ^ key[i % 32]);
        return new String(encoded, StandardCharsets.UTF_8);
    }

    /** HXE.py std_string(): extended size uses configured size_t width. */
    public String std_string() throws EOFException {
        long size = readByte();
        if (size == 0xFFL) size = readSizeT();
        if (size == 0L) return null;
        int payloadLength = checkedLength(size - 1L);
        return new String(readBytes(payloadLength), StandardCharsets.UTF_8);
    }

    public String pubgString() throws EOFException { return pubg_string(); }
    public String stdString() throws EOFException { return std_string(); }
}
