/*
 * NaveenRx100 Tool - Educational Module
 * EDUCATIONAL PURPOSE ONLY.
 * This code demonstrates Android development, local file handling, binary formats,
 * and cryptography for learning with files you own or are authorized to inspect.
 * Not intended for illegal modification of any software.
 * Developer: NaveenRx100 | Credit: @NaveenRx100
 */
package com.naveenrx100.tool.core;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.RandomAccessFile;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.CRC32;

/** Read-only Tencent PAK parser/extractor. It never modifies the source PAK. */
public final class TencentPakFile implements AutoCloseable {
    private final File file; private final byte[] content; private final boolean isOd;
    private final TencentPakInfo pakInfo; private String mountPoint=""; private byte[] zstdDict;
    private final List<TencentPakEntry> files=new ArrayList<>();
    private final Map<String,Map<String,TencentPakEntry>> index=new LinkedHashMap<>();
    private boolean indexHashValid;

    public TencentPakFile(File file,boolean isOd) throws IOException {
        if(file==null||!file.isFile())throw new IOException("PAK file does not exist: "+file);
        if(file.length()<=0||file.length()>Integer.MAX_VALUE)throw new IOException("Unsupported PAK file size: "+file.length());
        this.file=file;this.isOd=isOd;this.content=readAll(file);
        int[] ks=PakCrypto.zucKeystream(); this.pakInfo=new TencentPakInfo(content,ks);
        if(pakInfo.version<1||pakInfo.version>12)throw new IOException("Unsupported PAK version: "+pakInfo.version);
        verifyStemHash();loadIndex();
    }
    public TencentPakFile(File file) throws IOException {this(file,false);}
    private static byte[] readAll(File f)throws IOException {
        // Try a read-only memory map first; use a streaming byte-array fallback on devices/filesystems
        // that reject mapping. The parser owns a stable byte[] snapshot after this method returns.
        try(RandomAccessFile raf=new RandomAccessFile(f,"r");FileChannel channel=raf.getChannel()) {
            if(channel.size()>0&&channel.size()<=Integer.MAX_VALUE){MappedByteBuffer mapped=channel.map(FileChannel.MapMode.READ_ONLY,0,channel.size());byte[] data=new byte[(int)channel.size()];mapped.get(data);return data;}
        } catch(Exception mappingFailure) { Logger.warn("Memory mapping unavailable; using buffered read: "+mappingFailure.getMessage()); }
        try(FileInputStream in=new FileInputStream(f);ByteArrayOutputStream out=new ByteArrayOutputStream((int)f.length())){byte[] b=new byte[65536];int n;while((n=in.read(b))!=-1)out.write(b,0,n);return out.toByteArray();}
    }
    private void verifyStemHash(){if(!isOd&&pakInfo.version>=9){try{CRC32 crc=new CRC32();crc.update(file.getName().substring(0,file.getName().lastIndexOf('.')>0?file.getName().lastIndexOf('.'):file.getName().length()).getBytes("UTF-32LE"));if(crc.getValue()!=pakInfo.stem_hash)Logger.warn("PAK stem hash mismatch (file may be renamed)");}catch(Exception e){Logger.warn("Unable to verify PAK stem hash: "+e.getMessage());}}}
    private void loadIndex() throws IOException {
        long off=pakInfo.index_offset,sz=pakInfo.index_size;
        if(off<0||sz<0||off>content.length||sz>content.length-off)throw new IOException("Corrupted PAK: index range outside file (offset="+off+", size="+sz+")");
        byte[] raw=java.util.Arrays.copyOfRange(content,(int)off,(int)(off+sz)); byte[] idx=raw;
        if(pakInfo.index_encrypted){try{idx=PakCrypto.decryptIndex(raw,pakInfo);}catch(Exception e){Logger.warn("Index decryption failed; trying raw index: "+e.getMessage());idx=raw;}}
        indexHashValid=verifyIndexHash(idx);
        parseIndex(idx);
    }
    public boolean verifyIndexHash(){return indexHashValid;}
    private boolean verifyIndexHash(byte[] data){byte[] expected=pakInfo.index_hash;if(pakInfo.version>=6&&expected.length==20){byte[] actual=SHA1Hasher.hash(data);boolean ok=java.util.Arrays.equals(expected,actual);if(!ok)Logger.warn("PAK index SHA-1 mismatch");return ok;}return false;}
    private void parseIndex(byte[] idx)throws IOException {
        // This matches HXE.py: versions 1-10 are parsed in their footer/entry form but the
        // current Tencent directory-index layout is only accepted for versions 11 and 12.
        if(pakInfo.version<=10)throw new IOException("Unsupported version: "+pakInfo.version);
        try {
            PakReader r=new PakReader(idx);mountPoint=constructMountPoint(r.string());long nFiles=r.u4();if(nFiles>2_000_000L)throw new IOException("Corrupted PAK: unreasonable file count "+nFiles);
            for(int i=0;i<(int)nFiles;i++)files.add(new TencentPakEntry(r,pakInfo.version));
            long nDirs=r.u8();if(nDirs>2_000_000L)throw new IOException("Corrupted PAK: unreasonable directory count "+nDirs);
            for(int d=0;d<(int)nDirs;d++){
                String dir=normalizeInternalPath(r.string());long nEntries=r.u8();if(nEntries>2_000_000L)throw new IOException("Corrupted PAK: unreasonable directory entry count");Map<String,TencentPakEntry> children=new LinkedHashMap<>();
                for(int j=0;j<(int)nEntries;j++){String name=r.string();int idxEntry=r.i4();if(idxEntry<0){int entryIndex=~idxEntry;if(entryIndex>=0&&entryIndex<files.size())children.put(name,files.get(entryIndex));}}
                if(file.getPath().contains("zsdic")&&lastPart(dir).equals("zstddic")){if(children.size()==1)constructZstdDictionary(children.values().iterator().next());}
                else if(!children.isEmpty())index.put(dir,children);
            }
        } catch(RuntimeException e){throw new IOException("Unable to parse PAK index: "+e.getMessage(),e);}
    }
    private static String constructMountPoint(String s){return normalizeInternalPath(s);}
    private static String normalizeInternalPath(String s){if(s==null)return "";String t=s.replace('\\','/');while(t.startsWith("/"))t=t.substring(1);StringBuilder out=new StringBuilder();for(String part:t.split("/")){if(part.isEmpty()||part.equals("."))continue;if(part.equals(".."))continue;if(out.length()>0)out.append('/');out.append(part);}return out.toString();}
    private static String lastPart(String s){if(s==null||s.isEmpty())return "";int i=s.lastIndexOf('/');return i>=0?s.substring(i+1):s;}
    private void constructZstdDictionary(TencentPakEntry entry){if(entry.encrypted||entry.compression_method!=PakCompression.CM_NONE)throw new IllegalArgumentException("ZSTD dictionary entry must be unencrypted and uncompressed");byte[] data=peekContent(entry.offset,entry.size,0);PakReader r=new PakReader(data);long dictSize=r.u8();r.u4();long check=r.u4();if(dictSize!=check||dictSize>r.remaining())throw new IllegalArgumentException("Corrupted ZSTD dictionary entry");zstdDict=PakCompression.zstdDictionary(r.bytes((int)dictSize));}
    private byte[] peekContent(long offset,long size,int encMethod){int aligned=PakCrypto.alignEncryptedContentSize(checkedInt(size),encMethod);if(offset<0||offset>content.length)throw new IllegalArgumentException("PAK content offset out of range");long end=Math.min((long)content.length,offset+(long)aligned);return java.util.Arrays.copyOfRange(content,(int)offset,(int)end);}
    private byte[] peekBlock(PakCompressedBlock b,int encMethod){return peekContent(b.start,b.end-b.start,encMethod);}
    private static int checkedInt(long n){if(n<0||n>Integer.MAX_VALUE)throw new IllegalArgumentException("Invalid content size: "+n);return (int)n;}
    public void writeToDisk(File output,TencentPakEntry entry)throws IOException {
        if(output==null||entry==null)throw new IllegalArgumentException("output and entry are required");File parent=output.getAbsoluteFile().getParentFile();if(parent!=null&&!parent.isDirectory()&&!parent.mkdirs()&&!parent.isDirectory())throw new IOException("Cannot create output directory: "+parent);
        try(FileOutputStream out=new FileOutputStream(output)){
            if(entry.compression_method==PakCompression.CM_NONE){byte[] data=peekContent(entry.offset,entry.size,entry.encryption_method);if(entry.encrypted)data=PakCrypto.decryptBlock(data,output.toPath(),entry.encryption_method);out.write(data);return;}
            int[] order=PakCrypto.generateBlockIndices(entry.compressed_blocks.size(),entry.encryption_method);
            for(int i:order){if(i<0||i>=entry.compressed_blocks.size())continue;PakCompressedBlock block=entry.compressed_blocks.get(i);byte[] data=peekBlock(block,entry.encryption_method);if(entry.encrypted){try{data=PakCrypto.decryptBlock(data,output.toPath(),entry.encryption_method);}catch(RuntimeException ex){Logger.warn("Block decryption failed; trying compressed bytes: "+ex.getMessage());}}
                byte[] plain=PakCompression.decompressBlock(data,zstdDict,entry.compression_method);out.write(plain);
            }
        }
    }
    public void dump(File outputDir)throws IOException {dump(outputDir,null);}
    public void dump(File outputDir,ProgressCallback callback)throws IOException {
        if(outputDir==null)throw new IllegalArgumentException("output directory required");File root=outputDir;for(String p:mountPoint.split("/"))if(!p.isEmpty())root=new File(root,FileHelper.sanitizePart(p));if(!root.exists()&&!root.mkdirs())throw new IOException("Cannot create output directory: "+root);
        int total=0;for(Map<String,TencentPakEntry> m:index.values())total+=m.size();int done=0;
        for(Map.Entry<String,Map<String,TencentPakEntry>> d:index.entrySet()){
            File dir=root;for(String part:d.getKey().split("/"))if(!part.isEmpty())dir=new File(dir,FileHelper.sanitizePart(part));if(!dir.exists()&&!dir.mkdirs())throw new IOException("Cannot create directory: "+dir);
            for(Map.Entry<String,TencentPakEntry> f:d.getValue().entrySet()){
                String safe=FileHelper.sanitizePart(f.getKey());File target=new File(dir,safe);
                try{writeToDisk(target,f.getValue());}catch(Exception e){Logger.warn("Skipped "+safe+": "+e.getMessage());if(callback!=null)callback.onLog("Skipped "+safe+": "+e.getMessage());}
                done++;if(callback!=null)callback.onProgress(done,total,"Extracting "+safe);
            }
        }
        if(callback!=null)callback.onComplete("Extracted "+done+" entries to "+root.getAbsolutePath());
    }
    public Map<String,Object> detectDominantStyle(){Map<Integer,Integer> comps=new LinkedHashMap<>(),encs=new LinkedHashMap<>(),blocks=new LinkedHashMap<>();int encrypted=0,plain=0;for(TencentPakEntry e:files){inc(comps,e.compression_method);if(e.encrypted){encrypted++;inc(encs,e.encryption_method);}else plain++;if(e.compression_block_size>0)inc(blocks,e.compression_block_size);}int comp=PakCompression.CM_ZSTD,enc=0,block=0x10000;if(!files.isEmpty()){int best=-1;for(Map.Entry<Integer,Integer> e:comps.entrySet())if(e.getKey()!=PakCompression.CM_NONE&&e.getValue()>best){best=e.getValue();comp=e.getKey();}if(best<0)comp=PakCompression.CM_NONE;if(encrypted>plain){best=-1;for(Map.Entry<Integer,Integer> e:encs.entrySet())if(e.getValue()>best){best=e.getValue();enc=e.getKey();}}best=-1;for(Map.Entry<Integer,Integer> e:blocks.entrySet())if(e.getValue()>best){best=e.getValue();block=e.getKey();}}
        Map<String,Object> result=new LinkedHashMap<>();result.put("comp_method",comp);result.put("enc_method",enc);result.put("encrypted",encrypted>plain);result.put("block_size",block);return result;}
    private static void inc(Map<Integer,Integer> m,int k){m.put(k,m.containsKey(k)?m.get(k)+1:1);}
    public String getMountPoint(){return mountPoint;} public List<TencentPakEntry> getFiles(){return Collections.unmodifiableList(files);} public Map<String,Map<String,TencentPakEntry>> getIndex(){Map<String,Map<String,TencentPakEntry>> out=new LinkedHashMap<>();for(Map.Entry<String,Map<String,TencentPakEntry>> e:index.entrySet())out.put(e.getKey(),Collections.unmodifiableMap(e.getValue()));return Collections.unmodifiableMap(out);} public TencentPakInfo getPakInfo(){return pakInfo;} public File getFile(){return file;} public boolean isIndexHashValid(){return indexHashValid;}
    @Override public void close(){}
}
