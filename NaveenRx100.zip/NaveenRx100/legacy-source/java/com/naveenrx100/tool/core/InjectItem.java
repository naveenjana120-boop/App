/*
 * NaveenRx100 Tool - Injection Plan Item
 *
 * EDUCATIONAL PURPOSE ONLY
 * This code demonstrates binary file format analysis, archive writing, and
 * cryptography for learning purposes.
 *
 * Not intended for illegal modification of any software.
 * Developer: NaveenRx100
 * Credit: @NaveenRx100
 */
package com.naveenrx100.tool.core;

import java.io.File;

/** One input file and destination path for a generic NPAK archive. */
public final class InjectItem {
    public final String internalPath; public final File sourceFile; public final boolean encrypted; public final byte[] encryptionKey;
    public InjectItem(String internalPath,File sourceFile){this(internalPath,sourceFile,false,null);}
    public InjectItem(String internalPath,File sourceFile,boolean encrypted,byte[] encryptionKey){this.internalPath=PakIndexWriter.normalizePath(internalPath);this.sourceFile=sourceFile;this.encrypted=encrypted;this.encryptionKey=encryptionKey==null?null:encryptionKey.clone();if(this.internalPath.isEmpty())throw new IllegalArgumentException("internalPath is empty");if(encrypted&&(this.encryptionKey==null||(this.encryptionKey.length!=16&&this.encryptionKey.length!=24&&this.encryptionKey.length!=32)))throw new IllegalArgumentException("AES key required for encrypted item");}
}
