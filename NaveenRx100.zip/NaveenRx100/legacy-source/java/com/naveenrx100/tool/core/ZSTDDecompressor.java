/*
 * NaveenRx100 Tool - Educational Module
 * EDUCATIONAL PURPOSE ONLY.
 * This code demonstrates Android development, local file handling, binary formats,
 * and cryptography for learning with files you own or are authorized to inspect.
 * Not intended for illegal modification of any software.
 * Developer: NaveenRx100 | Credit: @NaveenRx100
 */
package com.naveenrx100.tool.core;

import com.github.luben.zstd.ZstdInputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.lang.reflect.Method;

/** zstd-jni-backed decompressor. Invalid frames follow HXE.py and return the input unchanged. */
public final class ZSTDDecompressor {
    private final byte[] dictionary;
    public ZSTDDecompressor(byte[] dictionary) { this.dictionary = dictionary == null ? null : dictionary.clone(); }
    public byte[] decompressBlock(byte[] input, byte[] dict, int method) {
        if (input == null) return new byte[0];
        byte[] selected = method == Constants.CM_ZSTD_DICT ? (dict != null ? dict : dictionary) : null;
        try (ZstdInputStream zin = new ZstdInputStream(new ByteArrayInputStream(input));
             ByteArrayOutputStream out = new ByteArrayOutputStream(Math.max(32, input.length * 2))) {
            if (selected != null && selected.length > 0) {
                // zstd-jni versions expose setDict(byte[]) or setDict(byte[], boolean).
                boolean applied = false;
                for (Method m : zin.getClass().getMethods()) {
                    if (m.getName().equals("setDict") && m.getParameterTypes().length == 1 && m.getParameterTypes()[0] == byte[].class) {
                        m.invoke(zin, (Object) selected); applied = true; break;
                    }
                }
                if (!applied) throw new IllegalStateException("Installed zstd-jni lacks ZstdInputStream.setDict(byte[])");
            }
            byte[] buf = new byte[8192]; int n;
            while ((n = zin.read(buf)) != -1) out.write(buf, 0, n);
            return out.toByteArray();
        } catch (Throwable e) { return input.clone(); }
    }
    public byte[] decompressBlock(byte[] input, int method) { return decompressBlock(input, dictionary, method); }
    public static byte[] decompress(byte[] input, byte[] dictionary, int method) { return new ZSTDDecompressor(dictionary).decompressBlock(input, dictionary, method); }
}
