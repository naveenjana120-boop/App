/*
 * NaveenRx100 Tool - Educational Module
 * EDUCATIONAL PURPOSE ONLY.
 * This code demonstrates Android development, local file handling, binary formats,
 * and cryptography for learning with files you own or are authorized to inspect.
 * Not intended for illegal modification of any software.
 * Developer: NaveenRx100 | Credit: @NaveenRx100
 */
package com.naveenrx100.tool.core;

import java.util.Arrays;

/** HXE.py's custom SM4-compatible 128-bit block cipher. Its S-box/FK/CK are source-exact. */
public final class SM4Cipher {
    private static final byte[] S_BOX = new byte[] {
        (byte) 0x34, (byte) 0x66, (byte) 0x25, (byte) 0x74, (byte) 0x89, (byte) 0x78, (byte) 0xE4, (byte) 0xA9, (byte) 0x5A, (byte) 0x41, (byte) 0xBC, (byte) 0x7A, (byte) 0xD6, (byte) 0x16, (byte) 0x21, (byte) 0x23,
        (byte) 0x4D, (byte) 0x61, (byte) 0xDA, (byte) 0x94, (byte) 0x9B, (byte) 0xDF, (byte) 0x13, (byte) 0x3C, (byte) 0x69, (byte) 0x3A, (byte) 0x31, (byte) 0x0A, (byte) 0x5F, (byte) 0xD7, (byte) 0x99, (byte) 0x95,
        (byte) 0xF1, (byte) 0xAE, (byte) 0x72, (byte) 0x3D, (byte) 0x07, (byte) 0x60, (byte) 0x24, (byte) 0xB6, (byte) 0x98, (byte) 0xEE, (byte) 0xC4, (byte) 0xA2, (byte) 0x2D, (byte) 0x88, (byte) 0xDD, (byte) 0x8D,
        (byte) 0x04, (byte) 0xEA, (byte) 0xBB, (byte) 0x11, (byte) 0xCA, (byte) 0x3E, (byte) 0x5D, (byte) 0xA1, (byte) 0xF6, (byte) 0x3F, (byte) 0xB0, (byte) 0x97, (byte) 0x80, (byte) 0x47, (byte) 0x2B, (byte) 0xA6,
        (byte) 0xE6, (byte) 0xF7, (byte) 0xD9, (byte) 0xB1, (byte) 0x59, (byte) 0xC0, (byte) 0x7C, (byte) 0xBE, (byte) 0x54, (byte) 0x28, (byte) 0xB7, (byte) 0x7E, (byte) 0x4F, (byte) 0xF8, (byte) 0x43, (byte) 0x6E,
        (byte) 0xA0, (byte) 0x50, (byte) 0x0E, (byte) 0xF5, (byte) 0x90, (byte) 0xB8, (byte) 0xFB, (byte) 0xA3, (byte) 0x7B, (byte) 0x62, (byte) 0x19, (byte) 0x46, (byte) 0x03, (byte) 0x2A, (byte) 0xB9, (byte) 0x8F,
        (byte) 0x9F, (byte) 0x77, (byte) 0xB4, (byte) 0x5B, (byte) 0x83, (byte) 0x87, (byte) 0x08, (byte) 0xEB, (byte) 0xE2, (byte) 0x1E, (byte) 0x42, (byte) 0xF0, (byte) 0x0F, (byte) 0xE8, (byte) 0x71, (byte) 0x6A,
        (byte) 0x75, (byte) 0xAD, (byte) 0x55, (byte) 0x1F, (byte) 0xB5, (byte) 0xAB, (byte) 0x33, (byte) 0xFA, (byte) 0x7F, (byte) 0x15, (byte) 0xBD, (byte) 0x85, (byte) 0xD8, (byte) 0x06, (byte) 0x68, (byte) 0xB3,
        (byte) 0x52, (byte) 0x30, (byte) 0x48, (byte) 0x0B, (byte) 0x00, (byte) 0xED, (byte) 0xEF, (byte) 0xB2, (byte) 0x57, (byte) 0x8E, (byte) 0xE7, (byte) 0x6C, (byte) 0xD5, (byte) 0xE5, (byte) 0x2E, (byte) 0x53,
        (byte) 0x82, (byte) 0x05, (byte) 0xF9, (byte) 0x81, (byte) 0xF4, (byte) 0x56, (byte) 0xBF, (byte) 0x8C, (byte) 0x4B, (byte) 0xE3, (byte) 0xDB, (byte) 0x4A, (byte) 0x91, (byte) 0x4C, (byte) 0x2C, (byte) 0xD3,
        (byte) 0x40, (byte) 0x29, (byte) 0x4E, (byte) 0x20, (byte) 0x14, (byte) 0x36, (byte) 0x79, (byte) 0x09, (byte) 0x6F, (byte) 0xD1, (byte) 0x37, (byte) 0xE0, (byte) 0x39, (byte) 0x0C, (byte) 0x8A, (byte) 0x92,
        (byte) 0x38, (byte) 0x12, (byte) 0x35, (byte) 0x6D, (byte) 0xE1, (byte) 0xFD, (byte) 0x93, (byte) 0x9A, (byte) 0x17, (byte) 0xD4, (byte) 0xC9, (byte) 0x9C, (byte) 0x6B, (byte) 0x84, (byte) 0x26, (byte) 0x9D,
        (byte) 0xAF, (byte) 0x76, (byte) 0xC1, (byte) 0x9E, (byte) 0xD0, (byte) 0x96, (byte) 0xC5, (byte) 0xCB, (byte) 0xE9, (byte) 0x73, (byte) 0x49, (byte) 0xD2, (byte) 0xCD, (byte) 0x64, (byte) 0xC3, (byte) 0xC7,
        (byte) 0x01, (byte) 0x7D, (byte) 0xF3, (byte) 0xAC, (byte) 0xFC, (byte) 0xDE, (byte) 0xA4, (byte) 0x44, (byte) 0x32, (byte) 0x1B, (byte) 0xC2, (byte) 0xBA, (byte) 0x1C, (byte) 0x02, (byte) 0xC6, (byte) 0x27,
        (byte) 0x45, (byte) 0x8B, (byte) 0xF2, (byte) 0x18, (byte) 0xA7, (byte) 0x10, (byte) 0x51, (byte) 0x1D, (byte) 0xC8, (byte) 0xCF, (byte) 0x63, (byte) 0xFF, (byte) 0x2F, (byte) 0x0D, (byte) 0x58, (byte) 0xCE,
        (byte) 0x65, (byte) 0xA5, (byte) 0xDC, (byte) 0x1A, (byte) 0x3B, (byte) 0x86, (byte) 0xFE, (byte) 0x22, (byte) 0x5C, (byte) 0xA8, (byte) 0x5E, (byte) 0x67, (byte) 0xAA, (byte) 0xEC, (byte) 0x70, (byte) 0xCC
    };
    private static final long[] FK = new long[] {
        0x46970E9CL, 0x4BC0685EL, 0x59056186L, 0xBCA2491EL
    };
    private static final long[] CK = new long[] {
        0x000EB92BL, 0x3A0AE783L, 0x9E3B5C67L, 0xADDBDABFL, 0x7B7484CBL, 0x49156C63L, 0xC79AB5E7L, 0x79EC9CFFL, 0x1725BEABL, 0x2FB89CA3L, 0x24808AD7L, 0xDDD28B1FL, 0x4740DA4BL, 0xBBC3EA73L, 0x247B30E7L, 0x91BE385FL, 0x0401248BL, 0x45FCD3A3L, 0x530B4CE7L, 0xC68DD35FL, 0xE3D16C2BL, 0x4F698C13L, 0x6B92C747L, 0x769EFB1FL, 0x4C73BE9BL, 0xC942B193L, 0xAD80D827L, 0x372FB33FL, 0x13CB6AABL, 0x2BDC0AA3L, 0x17A4A247L, 0xD5E96CAFL
    };
    private final int[] roundKeys = new int[32];
    public SM4Cipher(byte[] key) {
        if (key == null || key.length != 16) throw new IllegalArgumentException("SM4 key must be 16 bytes");
        int[] k = new int[4];
        for (int i=0;i<4;i++) k[i] = readIntBE(key, i*4) ^ (int)FK[i];
        for (int i=0;i<32;i++) {
            int t = k[(i+1)&3] ^ k[(i+2)&3] ^ k[(i+3)&3] ^ (int)CK[i];
            k[i&3] ^= transformKey(t);
            roundKeys[i] = k[i&3];
        }
    }
    private static int readIntBE(byte[] b, int p) { return ((b[p]&255)<<24)|((b[p+1]&255)<<16)|((b[p+2]&255)<<8)|(b[p+3]&255); }
    private static void writeIntBE(int v, byte[] b, int p) { b[p]=(byte)(v>>>24); b[p+1]=(byte)(v>>>16); b[p+2]=(byte)(v>>>8); b[p+3]=(byte)v; }
    private static int rol(int x, int n) { return (x << n) | (x >>> (32-n)); }
    private static int substitute(int x) {
        return ((S_BOX[(x>>>24)&255]&255)<<24)|((S_BOX[(x>>>16)&255]&255)<<16)|((S_BOX[(x>>>8)&255]&255)<<8)|(S_BOX[x&255]&255);
    }
    private static int transformData(int x) { x=substitute(x); return x ^ rol(x,2) ^ rol(x,10) ^ rol(x,18) ^ rol(x,24); }
    private static int transformKey(int x) { x=substitute(x); return x ^ rol(x,13) ^ rol(x,23); }
    public byte[] encryptBlock(byte[] block) { return cryptBlock(block, false); }
    public byte[] decryptBlock(byte[] block) { return cryptBlock(block, true); }
    public byte[] encrypt(byte[] block) { return encryptBlock(block); }
    public byte[] decrypt(byte[] block) { return decryptBlock(block); }
    private byte[] cryptBlock(byte[] block, boolean decrypt) {
        if (block == null || block.length != 16) throw new IllegalArgumentException("SM4 block must be 16 bytes");
        int[] x = new int[4]; for(int i=0;i<4;i++) x[i]=readIntBE(block,i*4);
        for(int i=0;i<32;i++) {
            int rk = roundKeys[decrypt ? 31-i : i];
            int t = x[1] ^ x[2] ^ x[3] ^ rk;
            int next = x[0] ^ transformData(t);
            x[0]=x[1]; x[1]=x[2]; x[2]=x[3]; x[3]=next;
        }
        byte[] out = new byte[16]; writeIntBE(x[3],out,0); writeIntBE(x[2],out,4); writeIntBE(x[1],out,8); writeIntBE(x[0],out,12); return out;
    }
    public byte[] decrypt(byte[] data, boolean blockAligned) {
        if (data == null || (data.length & 15) != 0) throw new IllegalArgumentException("SM4 ciphertext length must be a multiple of 16");
        byte[] out=new byte[data.length]; for(int p=0;p<data.length;p+=16) System.arraycopy(decryptBlock(Arrays.copyOfRange(data,p,p+16)),0,out,p,16); return out;
    }
    public static int sBoxLength() { return S_BOX.length; }
    public static int fkLength() { return FK.length; }
    public static int ckLength() { return CK.length; }
}
