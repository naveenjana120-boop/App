/*
 * NaveenRx100 Tool - Educational Module
 * EDUCATIONAL PURPOSE ONLY.
 * This code demonstrates Android development, local file handling, binary formats,
 * and cryptography for learning with files you own or are authorized to inspect.
 * Not intended for illegal modification of any software.
 * Developer: NaveenRx100 | Credit: @NaveenRx100
 */
package com.naveenrx100.tool.core;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;

/** Bounds-checked little-endian reader matching HXE.py Reader. */
final class PakReader {
    private final byte[] data; private int pos;
    PakReader(byte[] data) { this(data,0); }
    PakReader(byte[] data,int offset) { if(data==null)throw new IllegalArgumentException("buffer is null"); if(offset<0||offset>data.length)throw new IllegalArgumentException("bad offset"); this.data=data;this.pos=offset; }
    int position(){return pos;} int remaining(){return data.length-pos;}
    private void need(int n){if(n<0||n>data.length-pos)throw new IllegalArgumentException("Corrupted PAK: need "+n+" bytes at "+pos+", remaining "+(data.length-pos));}
    int u1(){need(1);return data[pos++]&255;}
    int i1(){need(1);return data[pos++];}
    long u4(){need(4);long v=(data[pos]&255L)|((data[pos+1]&255L)<<8)|((data[pos+2]&255L)<<16)|((data[pos+3]&255L)<<24);pos+=4;return v;}
    int i4(){return (int)u4();}
    long u8(){need(8);long v=0;for(int i=0;i<8;i++)v|=(data[pos+i]&255L)<<(8*i);pos+=8;return v;}
    byte[] bytes(int n){need(n);byte[] out=java.util.Arrays.copyOfRange(data,pos,pos+n);pos+=n;return out;}
    String string(){int n=i4();if(n==0)return "";if(n<0)throw new IllegalArgumentException("Negative PAK string length: "+n);byte[] raw=bytes(n);int end=raw.length;while(end>0&&raw[end-1]==0)end--;ByteArrayBuilder b=new ByteArrayBuilder(end);for(int i=0;i<end;i++)if(raw[i]!=0)b.add(raw[i]);return new String(b.toArray(),StandardCharsets.UTF_8);}
    private static final class ByteArrayBuilder {byte[] a;int n;ByteArrayBuilder(int c){a=new byte[c];}void add(byte x){a[n++]=x;}byte[] toArray(){return java.util.Arrays.copyOf(a,n);}}
}
