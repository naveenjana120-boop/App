/*
 * NaveenRx100 Tool - Educational Module
 * EDUCATIONAL PURPOSE ONLY.
 * This code demonstrates Android development, local file handling, binary formats,
 * and cryptography for learning with files you own or are authorized to inspect.
 * Not intended for illegal modification of any software.
 * Developer: NaveenRx100 | Credit: @NaveenRx100
 */
package com.naveenrx100.tool.core;

/** Immutable row model used by the PAK viewer. */
public final class PakFileItem {
    public final String path; public final long size,compressedSize; public final int method; public final boolean encrypted;
    public PakFileItem(String path,long size,long compressedSize,int method,boolean encrypted){this.path=path;this.size=size;this.compressedSize=compressedSize;this.method=method;this.encrypted=encrypted;}
    public String getPath(){return path;} public long getSize(){return size;} public long getCompressedSize(){return compressedSize;} public int getMethod(){return method;} public boolean isEncrypted(){return encrypted;}
}
