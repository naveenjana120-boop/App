/*
 * NaveenRx100 Tool - Educational Module
 * EDUCATIONAL PURPOSE ONLY.
 * This code demonstrates Android development, local file handling, binary formats,
 * and cryptography for learning with files you own or are authorized to inspect.
 * Not intended for illegal modification of any software.
 * Developer: NaveenRx100 | Credit: @NaveenRx100
 */
package com.naveenrx100.tool.core;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/** Parses only PAK metadata; does not extract or write entry content. */
public final class PakViewerData {
    private PakViewerData() {}
    public static List<PakFileItem> parsePakForViewer(File pakFile)throws IOException {
        List<PakFileItem> rows=new ArrayList<>();try(TencentPakFile pak=new TencentPakFile(pakFile,false)){
            String mount=pak.getMountPoint();for(Map.Entry<String,Map<String,TencentPakEntry>> d:pak.getIndex().entrySet())for(Map.Entry<String,TencentPakEntry> f:d.getValue().entrySet()){
                TencentPakEntry e=f.getValue();String path=join(join(mount,d.getKey()),f.getKey());rows.add(new PakFileItem(path,e.uncompressed_size,e.size,e.compression_method,e.encrypted));
            }
        }return rows;
    }
    private static String join(String a,String b){if(a==null||a.isEmpty())return b;if(b==null||b.isEmpty())return a;return a+"/"+b;}
}
