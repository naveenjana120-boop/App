/*
 * NaveenRx100 Tool - Educational Module
 * EDUCATIONAL PURPOSE ONLY.
 * This code demonstrates Android development, local file handling, binary formats,
 * and cryptography for learning with files you own or are authorized to inspect.
 * Not intended for illegal modification of any software.
 * Developer: NaveenRx100 | Credit: @NaveenRx100
 */
package com.naveenrx100.tool.core;

import java.io.EOFException;
import java.util.Arrays;

/** Byte-for-byte structural port of HXE.py bgmi_to_std/std_to_bgmi conversion. */
public final class LuaBytecodeConverter {
    private LuaBytecodeConverter() {}

    public static byte[] bgmi_to_std(byte[] data) throws EOFException {
        if (!StdLuaFormat.hasSignature(data)) throw new IllegalArgumentException("Not a valid Lua bytecode file");
        if (data.length < 34) throw new IllegalArgumentException("Lua bytecode is shorter than 34 bytes");
        BinaryReader reader = new BinaryReader(data, 4);
        BinaryWriter writer = new BinaryWriter();
        byte[] header = Arrays.copyOf(data, LuaHeader.HEADER_SIZE); header[13] = 4;
        writer.raw(header); reader.position(LuaHeader.HEADER_SIZE);
        int nibbleFlag=reader.readByte(); writer.writeByte(nibbleFlag);
        convertFunction(reader, writer, true);
        return writer.getData();
    }

    public static byte[] std_to_bgmi(byte[] data) throws EOFException {
        if (!StdLuaFormat.hasSignature(data)) throw new IllegalArgumentException("Not a valid Lua bytecode file");
        if (data.length < 34) throw new IllegalArgumentException("Lua bytecode is shorter than 34 bytes");
        int sizeT=(data[13]&0xff)==4 || (data[13]&0xff)==8 ? data[13]&0xff : 4;
        BinaryReader reader = new BinaryReader(data, sizeT);
        BinaryWriter writer = new BinaryWriter();
        byte[] header = Arrays.copyOf(data, LuaHeader.HEADER_SIZE); header[13] = 4;
        writer.raw(header); reader.position(LuaHeader.HEADER_SIZE);
        int nibbleFlag=reader.readByte(); writer.writeByte(nibbleFlag);
        convertFunction(reader, writer, false);
        return writer.getData();
    }

    /** HXE convert_file behavior: normalize nibble flag and swap nibbles after byte 33 when flag > 1. */
    public static byte[] convertBgmiFile(byte[] original) throws EOFException {
        if (original == null || original.length < 34 || !StdLuaFormat.hasSignature(original)) return original == null ? null : original.clone();
        byte[] normalized=original.clone(); int flag=normalized[33]&0xff;
        if (flag>2) { flag=0; normalized[33]=0; }
        if (flag>1) swapNibbles(normalized,34);
        try { return bgmi_to_std(normalized); }
        catch (RuntimeException | EOFException ex) { return original.clone(); }
    }

    /** HXE repack_to_pubg byte transform; caller supplies original header/nibble flag separately if needed. */
    public static byte[] convertStdToBgmiFile(byte[] standard, byte[] originalBgmi) throws EOFException {
        if (originalBgmi==null || originalBgmi.length<34 || !StdLuaFormat.hasSignature(originalBgmi)) throw new IllegalArgumentException("Original not valid Lua bytecode");
        byte[] converted=std_to_bgmi(standard);
        byte[] out=new byte[converted.length];
        System.arraycopy(originalBgmi,0,out,0,33); out[13]=originalBgmi[13];
        int flag=originalBgmi[33]&0xff; if(flag>2) flag=0; out[33]=(byte)flag;
        System.arraycopy(converted,34,out,34,converted.length-34);
        if(flag>1) swapNibbles(out,34);
        return out;
    }

    public static void swapNibbles(byte[] data, int fromIndex) {
        if(data==null) return;
        for(int i=Math.max(0,fromIndex);i<data.length;i++){ int b=data[i]&0xff; data[i]=(byte)(((b<<4)&0xf0)|((b>>>4)&0x0f)); }
    }

    /** Public alias matching HXE.py private function name. */
    public static void _convert_function(BinaryReader reader, BinaryWriter writer, boolean toStd) throws EOFException { convertFunction(reader,writer,toStd); }

    private static void convertFunction(BinaryReader reader, BinaryWriter writer, boolean toStd) throws EOFException {
        String source=toStd ? reader.pubg_string() : reader.std_string();
        writer.lua_string(source,!toStd);
        int lineDefined=reader.int32(); writer.int32(lineDefined);
        writer.int32(reader.int32());
        writer.writeByte(reader.readByte()); writer.writeByte(reader.readByte()); writer.writeByte(reader.readByte());
        long codeSize=reader.uint32(); ensureCount(codeSize,"instruction"); writer.uint32(codeSize);
        int[] opMap=toStd ? BGMIFormat.BGMI_TO_STD : BGMIFormat.STD_TO_BGMI;
        for(int i=0;i<(int)codeSize;i++){
            long raw=reader.uint32(); int bop=(int)(raw&0x3fL); int a=(int)((raw>>>6)&0xffL);
            int b=(int)((raw>>>23)&0x1ffL); int c=(int)((raw>>>14)&0x1ffL);
            int bx=(int)((raw>>>14)&0x3ffffL); int sbx=bx-131071; int ax=(int)((raw>>>6)&0x3ffffffL);
            int sop=bop<opMap.length && opMap[bop]>=0 ? opMap[bop] : bop;
            int fmt=BGMIFormat.formatForStandardOpcode(sop);
            writer.lua_inst(sop,a,b,c,bx,sbx,ax,fmt);
        }
        long constantCount=reader.uint32(); ensureCount(constantCount,"constant"); writer.uint32(constantCount);
        for(int i=0;i<(int)constantCount;i++){
            int type=reader.readByte(); writer.writeByte(type);
            switch(type){
                case 0: break;
                case 1: writer.writeByte(reader.readByte()); break;
                case 3: writer.writeDouble(reader.readDouble()); break;
                case 19: writer.int64(reader.int64()); break;
                case 4: case 20:
                    String s=toStd ? reader.pubg_string() : reader.std_string(); writer.lua_string(s,!toStd); break;
                default: throw new IllegalArgumentException(String.format("Unknown constant type 0x%02X",type));
            }
        }
        long upvalueCount=reader.uint32(); ensureCount(upvalueCount,"upvalue"); writer.uint32(upvalueCount);
        for(int i=0;i<(int)upvalueCount;i++){writer.writeByte(reader.readByte());writer.writeByte(reader.readByte());}
        long protoCount=reader.uint32(); ensureCount(protoCount,"nested prototype"); writer.uint32(protoCount);
        for(int i=0;i<(int)protoCount;i++) convertFunction(reader,writer,toStd);
        long lineCount=reader.uint32(); ensureCount(lineCount,"line-info");
        if(toStd){
            int[] lines=new int[(int)lineCount]; int current=lineDefined;
            for(int i=0;i<lines.length;i++){int d=reader.readByte(); current += d<=127 ? d : d-256; lines[i]=current;}
            writer.uint32(lines.length); for(int line:lines) writer.int32(line);
            long absCount=reader.uint32(); ensureCount(absCount,"absolute-line-info");
            for(int i=0;i<(int)absCount;i++){reader.uint32();reader.uint32();}
        } else {
            int[] lines=new int[(int)lineCount]; for(int i=0;i<lines.length;i++) lines[i]=reader.int32();
            writer.uint32(lines.length); int previous=lineDefined;
            for(int line:lines){int delta=line-previous; if(delta>=-128 && delta<=127) writer.writeByte(delta&0xff); else {writer.writeByte(0);writer.int32(delta);} previous=line;}
            writer.uint32(0);
        }
        long localCount=reader.uint32(); ensureCount(localCount,"local-variable"); writer.uint32(localCount);
        for(int i=0;i<(int)localCount;i++){
            String name=toStd ? reader.pubg_string() : reader.std_string(); writer.lua_string(name,!toStd);
            writer.int32(reader.int32()); writer.int32(reader.int32());
        }
        long upvalueNameCount=reader.uint32(); ensureCount(upvalueNameCount,"upvalue-name"); writer.uint32(upvalueNameCount);
        for(int i=0;i<(int)upvalueNameCount;i++){
            String name=toStd ? reader.pubg_string() : reader.std_string(); writer.lua_string(name,!toStd);
        }
    }
    private static void ensureCount(long count,String what){ if(count<0 || count>1_000_000L) throw new IllegalArgumentException("Invalid " + what + " count: " + count); }
}
