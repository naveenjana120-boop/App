/*
 * NaveenRx100 Tool - Educational Module
 * EDUCATIONAL PURPOSE ONLY.
 * This code demonstrates Android development, local file handling, binary formats,
 * and cryptography for learning with files you own or are authorized to inspect.
 * Not intended for illegal modification of any software.
 * Developer: NaveenRx100 | Credit: @NaveenRx100
 */
package com.naveenrx100.tool.core;

import java.io.EOFException;
import java.util.Arrays;

/** Self-checks for Lua header parsing, opcode tables, string XOR and chunk conversion. */
public final class LuaSelfTest {
    private LuaSelfTest() {}
    public static final class Report { public final int passed, failed; public final String details; Report(int p,int f,String d){passed=p;failed=f;details=d;} public boolean isSuccess(){return failed==0;} }
    public static Report run() {
        int passed=0,failed=0; StringBuilder log=new StringBuilder();
        try { byte[] h=syntheticChunk(); LuaHeader parsed=LuaHeader.parse(h); check(parsed.getSizeT()==4,"header size_t=4"); passed++; log.append("PASS header size_t=4\n"); } catch(Throwable t){failed++;log.append("FAIL header: ").append(t).append('\n');}
        try { if(BGMIFormat.BGMI_TO_STD.length!=64 || BGMIFormat.STD_FMT.length!=47) throw new AssertionError("table sizes"); for(int i=0;i<64;i++){int std=BGMIFormat.toStandard(i);int bgmi=BGMIFormat.toBgmi(std);if(bgmi!=i)throw new AssertionError("opcode roundtrip at "+i);} passed++;log.append("PASS opcode mapping round-trip\n"); } catch(Throwable t){failed++;log.append("FAIL opcodes: ").append(t).append('\n');}
        try { byte[] sample=syntheticChunk(); byte[] std=LuaBytecodeConverter.bgmi_to_std(sample); byte[] bgmi=LuaBytecodeConverter.std_to_bgmi(std); byte[] std2=LuaBytecodeConverter.bgmi_to_std(bgmi); if(!Arrays.equals(std,std2)) throw new AssertionError("converted bytecode differs after round-trip"); passed++;log.append("PASS BGMI/STD structural round-trip\n"); } catch(Throwable t){failed++;log.append("FAIL conversion: ").append(t).append('\n');}
        try { BinaryWriter w=new BinaryWriter(); w.lua_string("XOR-check",true); BinaryReader r=new BinaryReader(w.getData(),4); if(!"XOR-check".equals(r.pubg_string())) throw new AssertionError("XOR mismatch"); passed++;log.append("PASS string XOR\n"); } catch(Throwable t){failed++;log.append("FAIL string XOR: ").append(t).append('\n');}
        return new Report(passed,failed,log.toString());
    }
    private static void check(boolean b,String m){if(!b)throw new AssertionError(m);}
    /** Minimal valid HXE chunk with empty code/constants/prototypes/debug sections. */
    private static byte[] syntheticChunk() throws EOFException {
        BinaryWriter w=new BinaryWriter(); byte[] header=new byte[33]; header[0]=0x1b;header[1]='L';header[2]='u';header[3]='a';header[4]=0x53;header[5]=0;header[6]=0x19;header[7]=(byte)0x93;header[8]=0x0d;header[9]=0x0a;header[10]=0x1a;header[11]=0x0a;header[12]=4;header[13]=4;header[14]=4;header[15]=8;header[16]=8;w.raw(header);w.writeByte(0);w.lua_string((String)null,true);w.int32(0);w.int32(0);w.writeByte(0);w.writeByte(0);w.writeByte(0);w.uint32(0);w.uint32(0);w.uint32(0);w.uint32(0);w.uint32(0);w.uint32(0);w.uint32(0);w.uint32(0);return w.getData();
    }
}
