/*
 * NaveenRx100 Tool - Educational Module
 * EDUCATIONAL PURPOSE ONLY.
 * This code demonstrates Android development, local file handling, binary formats,
 * and cryptography for learning with files you own or are authorized to inspect.
 * Not intended for illegal modification of any software.
 * Developer: NaveenRx100 | Credit: @NaveenRx100
 */
package com.naveenrx100.tool.core;

import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;

/** Little-endian writer matching HXE.py BinaryWriter conventions. */
public final class BinaryWriter {
    private final ByteArrayOutputStream buffer = new ByteArrayOutputStream();

    public void writeByte(int value) { buffer.write(value & 0xFF); }
    public void byteValue(int value) { writeByte(value); }

    public void int32(int value) {
        buffer.write(value & 0xFF);
        buffer.write((value >>> 8) & 0xFF);
        buffer.write((value >>> 16) & 0xFF);
        buffer.write((value >>> 24) & 0xFF);
    }

    public void uint32(long value) { int32((int) value); }

    public void int64(long value) {
        for (int i = 0; i < 8; i++) buffer.write((int) ((value >>> (8 * i)) & 0xFFL));
    }

    public void writeDouble(double value) { int64(Double.doubleToRawLongBits(value)); }
    public void doubleValue(double value) { writeDouble(value); }

    public void raw(byte[] bytes) {
        if (bytes == null) throw new IllegalArgumentException("bytes must not be null");
        buffer.write(bytes, 0, bytes.length);
    }

    /** Python-compatible length-prefixed string writer. isPubg enables the HXE XOR transform. */
    public void lua_string(String value, boolean isPubg) {
        if (value == null) { writeByte(0); return; }
        lua_string(value.getBytes(StandardCharsets.UTF_8), isPubg);
    }

    public void lua_string(byte[] value, boolean isPubg) {
        if (value == null) { writeByte(0); return; }
        long size = (long) value.length + 1L;
        if (size < 0xFFL) {
            writeByte((int) size);
        } else {
            writeByte(0xFF);
            uint32(size);
        }
        if (isPubg) {
            byte[] encoded = value.clone();
            byte[] key = Constants.STRING_XOR_KEY;
            for (int i = 0; i < encoded.length; i++) encoded[i] = (byte) (encoded[i] ^ key[i % 32]);
            raw(encoded);
        } else {
            raw(value);
        }
    }

    public void luaString(String value, boolean isPubg) { lua_string(value, isPubg); }

    /** Encodes Lua 5.3 instruction formats using the bit layout from HXE.py. */
    public void lua_inst(int op, int a, int b, int c, int bx, int sbx, int ax, int fmt) {
        long result;
        op &= 0x3F;
        if (fmt == Constants.iABC) {
            result = op | (((long) a & 0xFFL) << 6)
                    | (((long) c & 0x1FFL) << 14)
                    | (((long) b & 0x1FFL) << 23);
        } else if (fmt == Constants.iABx) {
            result = op | (((long) a & 0xFFL) << 6)
                    | (((long) bx & 0x3FFFFL) << 14);
        } else if (fmt == Constants.iAsBx) {
            result = op | (((long) a & 0xFFL) << 6)
                    | ((((long) sbx + 131071L) & 0x3FFFFL) << 14);
        } else if (fmt == Constants.iAx) {
            result = op | (((long) ax & 0x3FFFFFFL) << 6);
        } else {
            result = 0L;
        }
        uint32(result);
    }

    public void lua_inst(int op, int a, int b, int c, int bx, int sbx, int ax, InstructionFormat fmt) {
        lua_inst(op, a, b, c, bx, sbx, ax, fmt.value);
    }

    public byte[] get_data() { return buffer.toByteArray(); }
    public byte[] getData() { return get_data(); }
    public int size() { return buffer.size(); }

    public enum InstructionFormat {
        iABC(Constants.iABC), iABx(Constants.iABx), iAsBx(Constants.iAsBx), iAx(Constants.iAx);
        public final int value;
        InstructionFormat(int value) { this.value = value; }
    }
}
