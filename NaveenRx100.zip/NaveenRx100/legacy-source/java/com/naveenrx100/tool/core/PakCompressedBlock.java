/*
 * NaveenRx100 Tool - Educational Module
 * EDUCATIONAL PURPOSE ONLY.
 * This code demonstrates Android development, local file handling, binary formats,
 * and cryptography for learning with files you own or are authorized to inspect.
 * Not intended for illegal modification of any software.
 * Developer: NaveenRx100 | Credit: @NaveenRx100
 */
package com.naveenrx100.tool.core;

/** Absolute [start,end) byte range of one compressed block. */
public final class PakCompressedBlock {
    public final long start,end;
    public PakCompressedBlock(PakReader reader){start=reader.u8();end=reader.u8();if(end<start)throw new IllegalArgumentException("Corrupted PAK: compressed block end precedes start");}
    public PakCompressedBlock(long start,long end){if(start<0||end<start)throw new IllegalArgumentException("invalid block range");this.start=start;this.end=end;}
}
