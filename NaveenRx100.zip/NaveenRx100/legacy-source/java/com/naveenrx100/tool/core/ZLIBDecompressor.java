/*
 * NaveenRx100 Tool - Educational Module
 * EDUCATIONAL PURPOSE ONLY.
 * This code demonstrates Android development, local file handling, binary formats,
 * and cryptography for learning with files you own or are authorized to inspect.
 * Not intended for illegal modification of any software.
 * Developer: NaveenRx100 | Credit: @NaveenRx100
 */
package com.naveenrx100.tool.core;

import java.io.ByteArrayOutputStream;
import java.util.zip.DataFormatException;
import java.util.zip.Inflater;

/** HXE.py-compatible zlib decompressor: returns the original bytes if decompression fails. */
public final class ZLIBDecompressor {
    private ZLIBDecompressor() {}
    public static byte[] decompressBlock(byte[] input) {
        if (input == null) return new byte[0];
        Inflater inflater = new Inflater(false);
        try {
            inflater.setInput(input);
            ByteArrayOutputStream out = new ByteArrayOutputStream(Math.max(32, input.length * 2));
            byte[] buffer = new byte[8192];
            while (!inflater.finished()) {
                int n = inflater.inflate(buffer);
                if (n > 0) { out.write(buffer, 0, n); continue; }
                if (inflater.needsDictionary() || inflater.needsInput()) break;
                throw new DataFormatException("Inflater made no progress");
            }
            if (!inflater.finished()) return input.clone();
            return out.toByteArray();
        } catch (Exception e) {
            return input.clone();
        } finally { inflater.end(); }
    }
    public static byte[] decompress_block(byte[] input) { return decompressBlock(input); }
}
