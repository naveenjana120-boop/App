/*
 * NaveenRx100 Tool - PakToolsController
 *
 * EDUCATIONAL PURPOSE ONLY
 * This code demonstrates binary file format analysis,
 * archive writing, and cryptography for learning purposes.
 *
 * Not intended for illegal modification of any software.
 *
 * Developer: NaveenRx100
 * Credit: @NaveenRx100
 */
package com.naveenrx100.tool.ui;

import android.app.Activity;
import android.app.ProgressDialog;
import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;

import com.naveenrx100.tool.pak.PakInjector;
import com.naveenrx100.tool.pak.PakOperations;

import java.io.File;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Controller for PAK-side UI actions. Owns the background executor, drives
 * ProgressDialog, and routes results back to the Activity on the main thread.
 */
public final class PakToolsController {

    private final Activity activity;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private ProgressDialog dialog;
    private final AtomicBoolean cancelFlag = new AtomicBoolean(false);

    public PakToolsController(Activity activity) {
        this.activity = activity;
    }

    public void shutdown() {
        executor.shutdownNow();
    }

    // ---------------------------------------------------------------
    // Public entry points used by PakToolsActivity
    // ---------------------------------------------------------------
    public void extractAll(File pak, File outDir) {
        runWithDialog("Extracting PAK", (cb) ->
                PakOperations.extractAll(pak, outDir, cb));
    }

    public void repack(File pak, File editedDir, File outPak,
                       String targetPath, boolean forceAdd,
                       Map<String, String> pathMap) {
        runWithDialog("Repacking PAK", (cb) ->
                PakOperations.repack(pak, editedDir, outPak, targetPath,
                        forceAdd, pathMap, cb));
    }

    public void buildNew(File template, File editDir, File outPak,
                         String targetPath, Map<String, String> pathMap) {
        runWithDialog("Building new PAK", (cb) ->
                PakOperations.buildNew(template, editDir, outPak, targetPath,
                        pathMap, cb));
    }

    public void inject(File pak, List<PakInjector.InjectItem> plan,
                       File outPak, boolean addMarker) {
        runWithDialog("Injecting files", (cb) ->
                PakOperations.inject(pak, plan, outPak, addMarker, cb));
    }

    // ---------------------------------------------------------------
    // Internal
    // ---------------------------------------------------------------
    private interface Operation {
        boolean run(PakOperations.Callback cb);
    }

    private void runWithDialog(String title, Operation op) {
        cancelFlag.set(false);

        main.post(() -> {
            dialog = new ProgressDialog(activity);
            dialog.setTitle(title);
            dialog.setMessage("Starting…");
            dialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
            dialog.setMax(100);
            dialog.setCancelable(false);
            dialog.setButton(ProgressDialog.BUTTON_NEGATIVE, "Cancel",
                    (d, w) -> cancelFlag.set(true));
            dialog.show();
        });

        executor.execute(() -> {
            final boolean[] ok = {false};
            final String[] finalMsg = {""};

            PakOperations.Callback cb = new PakOperations.Callback() {
                private int lastPct = -1;

                @Override public void onStage(String stage) {
                    main.post(() -> {
                        if (dialog != null) dialog.setMessage(stage);
                    });
                }
                @Override public void onProgress(int current, int total, String label) {
                    if (total <= 0) return;
                    int pct = (int) (100L * current / total);
                    if (pct == lastPct) return;
                    lastPct = pct;
                    main.post(() -> {
                        if (dialog != null) {
                            dialog.setProgress(pct);
                            String shortLabel = label.length() > 60
                                    ? "…" + label.substring(label.length() - 57)
                                    : label;
                            dialog.setMessage(shortLabel);
                        }
                    });
                }
                @Override public void onError(String message, Throwable cause) {
                    finalMsg[0] = message + (cause != null ? ": " + cause.getMessage() : "");
                    ok[0] = false;
                }
                @Override public void onDone(String message) {
                    finalMsg[0] = message;
                    ok[0] = true;
                }
                @Override public boolean isCancelled() {
                    return cancelFlag.get();
                }
            };

            try {
                op.run(cb);
            } catch (Throwable t) {
                ok[0] = false;
                finalMsg[0] = "Unhandled error: " + t.getMessage();
            }

            main.post(() -> {
                if (dialog != null && dialog.isShowing()) {
                    try { dialog.dismiss(); } catch (Throwable ignored) {}
                    dialog = null;
                }
                Toast.makeText(activity,
                        (ok[0] ? "✓ " : "✗ ") + finalMsg[0],
                        ok[0] ? Toast.LENGTH_LONG : Toast.LENGTH_LONG).show();
                onResult(ok[0], finalMsg[0]);
            });
        });
    }

    /** Override hook for Activity to react (e.g., refresh file list). */
    protected void onResult(boolean success, String message) {
        // default no-op
    }
}